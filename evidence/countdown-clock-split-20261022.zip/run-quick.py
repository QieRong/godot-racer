"""Run the existing Quick 15 suite once against the isolated source snapshot."""
from pathlib import Path
import json
import subprocess
import time
from zipfile import ZipFile

out = Path(__file__).resolve().parent
repo = out.parent.parent
root = out / 'source-snapshot'
with ZipFile(repo / 'godot-logs/exit-drain-20261021/source-snapshot.zip') as archive:
    for name in archive.namelist():
        target = (root / name).resolve()
        if not target.is_relative_to(root.resolve()):
            raise RuntimeError('Archive path outside snapshot')
        if not target.exists():
            archive.extract(name, root)
command = [r'C:\Program Files\PowerShell\7\pwsh.exe', '-File',
           str(root / '04-Godot启动器/run-all-checks.ps1'), '-Quick', '-RenderFps', '120']
started = time.monotonic()
with (out / 'quick-120.console.log').open('xb') as console:
    process = subprocess.Popen(command, cwd=root, stdout=console, stderr=subprocess.STDOUT,
                               creationflags=subprocess.CREATE_NO_WINDOW)
    receipt = dict(command=command, pid=process.pid, source_base='8e2de4d',
                   changes=['tests/countdown_scene_test.gd', 'tests/countdown_clock_contract_test.gd'])
    (out / 'quick-120.process.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding='utf-8')
    code = process.wait()
receipt.update(exit=code, elapsed_s=round(time.monotonic()-started, 3))
(out / 'quick-120.result.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(receipt, ensure_ascii=False), flush=True)
raise SystemExit(code)
