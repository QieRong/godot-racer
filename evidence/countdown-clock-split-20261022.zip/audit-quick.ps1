$ErrorActionPreference = 'Stop'
$outDir = $PSScriptRoot
$suite = Get-Content -LiteralPath (Join-Path $outDir 'quick-120.result.json') -Raw | ConvertFrom-Json
if ($suite.exit -ne 0) { throw 'Suite did not exit 0; child exits cannot be inferred as zero' }
. (Join-Path $outDir 'source-snapshot/04-Godot启动器/check-result.ps1')
$records = @(Get-ChildItem -LiteralPath (Join-Path $outDir 'source-snapshot/godot-logs') -Filter 'check-*.log' | ForEach-Object {
    $raw = Get-Content -LiteralPath $_.FullName -Raw
    $checkName = $_.BaseName.Substring(6)
    # 原runner只有childExit=0才将一行标PASS；suite exit0意味着所有子项均满足。
    # 直接复用原解析器的RUNID分段、INFO/SKIP与最终计数规则，不另造版本。
    $verdict = Get-CheckResult -LogText $raw -Check $checkName -ProcessExitCode 0
    $logErrors = $raw -match 'SCRIPT ERROR|Parse Error|ObjectDB instances leaked|resources still in use'
    [pscustomobject]@{
        log = $_.Name
        evidence_ok = $verdict.Passed -and -not $logErrors
        reasons = $verdict.Reasons
        process_exit_basis = 'Existing suite requires childExit=0 for each PASS; suite final exit=0'
        extra_script_or_leak_error = $logErrors
    }
})
$records | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $outDir 'quick-audit.json') -Encoding utf8
if ($records.Count -ne 13 -or @($records | Where-Object { -not $_.evidence_ok }).Count -gt 0) {
    throw 'Quick final evidence audit failed; see quick-audit.json'
}
Write-Output "Quick final evidence: $($records.Count)/13 game logs consistent with existing result parser"
