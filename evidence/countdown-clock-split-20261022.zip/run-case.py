"""Single real-exe run; preserve every result, PID and output without retries."""
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
from zipfile import ZipFile

OUT = Path(__file__).resolve().parent
REPO = OUT.parent.parent
PROJECT = OUT / 'source-snapshot' / 'godot-racer'
OLD = REPO / 'godot-logs' / 'exit-drain-20261021'

if sys.argv[1] == 'prepare':
    with ZipFile(OLD / 'source-snapshot.zip') as archive:
        for name in archive.namelist():
            if name.startswith('godot-racer/'):
                archive.extract(name, OUT / 'source-snapshot')
    shutil.copytree(OLD / 'source-snapshot/godot-racer/.godot', PROJECT / '.godot')
    records = []
    with ZipFile(OLD / 'source-snapshot.zip') as archive:
        for name in archive.namelist():
            if name.startswith('godot-racer/') and not name.endswith('/'):
                path = OUT / 'source-snapshot' / name
                records.append(dict(path=name, same=path.read_bytes() == archive.read(name)))
    (OUT / 'source-audit-before.json').write_text(json.dumps(records, indent=2), encoding='utf-8')
    print('Snapshot source files:', len(records), 'mismatches:', sum(not r['same'] for r in records))
    sys.exit(0 if all(r['same'] for r in records) else 1)

name, script, fps, *extra = sys.argv[1:]
engine_extra = []
for arg in extra[:]:
    if arg.startswith('--engine-frame-delay='):
        engine_extra += ['--frame-delay', str(int(arg.split('=', 1)[1]))]
        extra.remove(arg)
if (OUT / f'{name}.process.json').exists():
    raise SystemExit('Refusing to overwrite existing evidence: ' + name)
command = [r'E:\godot\Godot_v4.4.1-stable_win64.exe', '--path', str(PROJECT),
           '--verbose', '--log-file', str(OUT / f'{name}.log'), '--headless',
           '--audio-driver', 'Dummy', '--script', script, *engine_extra,
           '--', f'--render-fps={fps}', *extra]
start = time.monotonic()
process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                           creationflags=subprocess.CREATE_NO_WINDOW)
metadata = dict(case=name, pid=process.pid, command=command,
                script_sha256=hashlib.sha256((PROJECT / script.removeprefix('res://')).read_bytes()).hexdigest())
metadata['subject_sha256'] = hashlib.sha256((PROJECT / 'tests/countdown_scene_test.gd').read_bytes()).hexdigest()
(OUT / f'{name}.process.json').write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding='utf-8')
timeout = False
try:
    stdout, stderr = process.communicate(timeout=60)
except subprocess.TimeoutExpired:
    timeout = True
    process.kill()
    stdout, stderr = process.communicate()
(OUT / f'{name}.console.log').write_bytes(stdout)
(OUT / f'{name}.stderr.log').write_bytes(stderr)
(OUT / f'{name}.exit.txt').write_text(str(process.returncode), encoding='utf-8')
raw = stdout.decode('utf-8', errors='replace') + stderr.decode('utf-8', errors='replace')
summaries = re.findall(r'^CASES: (\d+) PASS: (\d+) FAIL: (\d+)\r?$', raw, re.M)
clock_summaries = re.findall(r'^RACE_CLOCK_SCENE_SUMMARY pass=(\d+) fail=(\d+) fps=(\d+)\r?$', raw, re.M)
countdown_ok = (summaries == [('30', '30', '0')] and raw.count('COUNTDOWN_SCENE_PASS') == 1
                and len(re.findall(r'^  ✔ ', raw, re.M)) == 30)
clock_ok = (clock_summaries == [('41', '0', fps)] and raw.count('RACE_CLOCK_SCENE_PASS') == 1
            and len(re.findall(r'^PASS ', raw, re.M)) == 41)
leak = bool(re.search(r'ObjectDB instances leaked|Leaked instance:|resources still in use', raw))
script_error = bool(re.search(r'SCRIPT ERROR|Parse Error', raw))
contract_summaries = re.findall(r'^CLOCK_CONTRACT_SUMMARY pass=(\d+) fail=(\d+)\r?$', raw, re.M)
contract_ok = (contract_summaries == [('21', '0')] and raw.count('CLOCK_CONTRACT_PASS') == 1
               and len(re.findall(r'^PASS ', raw, re.M)) == 21)
if script.endswith('/countdown_scene_test.gd'):
    expected = countdown_ok
elif script.endswith('/countdown_clock_contract_test.gd'):
    expected = contract_ok
else:
    expected = clock_ok
metadata.update(exit=process.returncode, elapsed_s=round(time.monotonic()-start, 3),
                timeout=timeout, leak=leak, script_error=script_error,
                summaries=summaries or clock_summaries or contract_summaries,
                errors=re.findall(r'^.*ERROR:.*$', raw, re.M),
                passed=process.returncode == 0 and expected and not (timeout or leak or script_error))
(OUT / f'{name}.result.json').write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(metadata, ensure_ascii=False), flush=True)
sys.exit(0 if metadata['passed'] else 1)
