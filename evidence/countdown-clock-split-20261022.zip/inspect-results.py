from pathlib import Path
import json
from zipfile import ZipFile

out = Path(__file__).resolve().parent
repo = out.parent.parent
diffs = []
with ZipFile(repo / 'godot-logs/exit-drain-20261021/source-snapshot.zip') as archive:
    for name in archive.namelist():
        if name.startswith('godot-racer/') and not name.endswith('/'):
            if (out / 'source-snapshot' / name).read_bytes() != archive.read(name):
                diffs.append(name)
lines = {name: len((repo / name).read_text(encoding='utf-8').splitlines()) for name in (
    'godot-racer/tests/countdown_scene_test.gd', 'godot-racer/tests/countdown_clock_contract_test.gd')}
summary = dict(source_base='8e2de4d', head_at_start='b7508c1',
               modified_archive_files=diffs, new_files=['godot-racer/tests/countdown_clock_contract_test.gd'],
               gd_lines=lines, results=[])
summary['global_line_debt'] = []
for path in (repo / 'godot-racer').rglob('*.gd'):
    if '.godot' in path.parts or 'addons' in path.parts:
        continue
    count = len(path.read_text(encoding='utf-8-sig').splitlines())
    if count > 1000:
        summary['global_line_debt'].append(dict(path=str(path.relative_to(repo)), lines=count))
summary['authored_gd_matches_snapshot'] = all(
    (repo / name).read_bytes() == (out / 'source-snapshot' / name).read_bytes() for name in lines)
for path in sorted(out.glob('*.result.json')):
    result = json.loads(path.read_text(encoding='utf-8'))
    summary['results'].append(result)
(out / 'final-audit.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
print('Source differences:', diffs, 'GD lines:', lines)
for r in summary['results']:
    print(r.get('case', 'quick-120'), 'exit', r['exit'], 'passed', r.get('passed'), 'leak', r.get('leak'))
