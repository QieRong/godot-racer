from pathlib import Path
import hashlib
import json
from zipfile import ZipFile, ZIP_DEFLATED

out = Path(__file__).resolve().parent
repo = out.parent.parent
target = repo / 'evidence/countdown-clock-split-20261022.zip'
assert (out / 'quick-120.result.json').exists(), 'Wait for the suite final receipt'
for name in ('quick-audit.exit.txt', 'docs-final2.exit.txt', 'readme-final2.exit.txt'):
    assert (out / name).read_text(encoding='utf-8-sig').strip() == '0', name
audit = json.loads((out / 'final-audit.json').read_text(encoding='utf-8'))
assert audit['authored_gd_matches_snapshot'], 'Authored GD differs from tested source'
assert all(count <= 1000 for count in audit['gd_lines'].values()), 'Touched GD line limit'
assert not target.exists(), 'Refusing to overwrite evidence'
files = {p.name: p.read_bytes() for p in out.iterdir()
         if p.is_file() and p.suffix in ('.py', '.ps1', '.json', '.log', '.txt')}
for path in (out / 'source-snapshot/godot-logs').rglob('*'):
    if path.is_file() and path.suffix in ('.log', '.json', '.txt'):
        files['quick-engine/' + path.relative_to(out / 'source-snapshot/godot-logs').as_posix()] = path.read_bytes()
for name in ('plan/countdown-clock-split-20261022.md', 'HANDOVER-2026-10-22-CLOCK-SPLIT.md',
             'godot-racer/docs/testing.md', 'godot-racer/tests/countdown_scene_test.gd',
             'godot-racer/tests/countdown_clock_contract_test.gd',
             'godot-racer/tests/countdown_clock_contract_test.gd.uid'):
    files[name] = (repo / name).read_bytes()
files['historical/countdown_scene_test.b7508c1.gd'] = (
    repo / 'godot-logs/countdown-clock-20261022/source-snapshot/godot-racer/tests/countdown_scene_test.gd').read_bytes()
for name in ('run-all-checks.ps1', 'run-check.ps1', 'check-result.ps1'):
    files['quick-runner/' + name] = (out / 'source-snapshot' / '04-Godot启动器' / name).read_bytes()
manifest = ''.join(hashlib.sha256(data).hexdigest() + '  ' + name + '\n'
                   for name, data in sorted(files.items()))
with ZipFile(target, 'w', ZIP_DEFLATED) as archive:
    for name, data in sorted(files.items()):
        archive.writestr(name, data)
    archive.writestr('MANIFEST.sha256', manifest)
with ZipFile(target) as archive:
    for line in archive.read('MANIFEST.sha256').decode('utf-8').splitlines():
        digest, name = line.split('  ', 1)
        assert hashlib.sha256(archive.read(name)).hexdigest() == digest, name
digest = hashlib.sha256(target.read_bytes()).hexdigest()
target.with_suffix('.zip.sha256').write_text(digest + '  ' + target.name + '\n', encoding='utf-8')
(out / 'package-verification.json').write_text(json.dumps(dict(
    files=len(files), manifest_verified=True, zip_sha256=digest, bytes=target.stat().st_size), indent=2), encoding='utf-8')
print('Verified files:', len(files), 'ZIP bytes:', target.stat().st_size, 'SHA256:', digest)
