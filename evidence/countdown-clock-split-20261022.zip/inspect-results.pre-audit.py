from pathlib import Path
import json
import re
from zipfile import ZipFile

out = Path(__file__).resolve().parent
repo = out.parent.parent
diffs = []
with ZipFile(repo / 'godot-logs/exit-drain-20261021/source-snapshot.zip') as archive:
    for name in archive.namelist():
        if name.startswith('godot-racer/') and not name.endswith('/'):
            if (out / 'source-snapshot' / name).read_bytes() != archive.read(name):
                diffs.append(name)
lines = {name: len((repo / name).read_text(encoding='utf-8').splitlines()) for name in (
    'godot-racer/tests/countdown_scene_test.gd', 'godot-racer/tests/countdown_clock_contract_test.gd')}
summary = dict(source_base='8e2de4d', head_at_start='b7508c1',
               modified_archive_files=diffs, new_files=['godot-racer/tests/countdown_clock_contract_test.gd'],
               gd_lines=lines, results=[])
summary['global_line_debt'] = []
for path in (repo / 'godot-racer').rglob('*.gd'):
    if '.godot' in path.parts or 'addons' in path.parts:
        continue
    count = len(path.read_text(encoding='utf-8-sig').splitlines())
    if count > 1000:
        summary['global_line_debt'].append(dict(path=str(path.relative_to(repo)), lines=count))
summary['authored_gd_matches_snapshot'] = all(
    (repo / name).read_bytes() == (out / 'source-snapshot' / name).read_bytes() for name in lines)
for path in sorted(out.glob('*.result.json')):
    result = json.loads(path.read_text(encoding='utf-8'))
    summary['results'].append(result)
(out / 'final-audit.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
if (out / 'quick-120.result.json').exists():
    records = []
    for path in sorted((out / 'source-snapshot/godot-logs').glob('check-*.log')):
        raw = path.read_text(encoding='utf-8', errors='replace')
        outcomes = [json.loads(line.split('|', 1)[1]) for line in raw.splitlines() if line.startswith('OUTCOME|')]
        assertions = [json.loads(line.split('|', 1)[1]) for line in raw.splitlines() if line.startswith('ASSERT|')]
        ok = (len(outcomes) == 1 and bool(assertions) and
              outcomes[0]['assertion_records'] == len(assertions) and
              outcomes[0]['measurement_status'] == 'COMPLETE' and
              outcomes[0]['finished'] and outcomes[0]['failed_assertions'] == 0 and
              all(a['result'] == 'PASS' for a in assertions) and
              not re.search(r'SCRIPT ERROR|Parse Error|ObjectDB instances leaked|resources still in use', raw))
        records.append(dict(log=path.name, assertions=len(assertions), evidence_ok=ok, outcomes=outcomes))
    assert len(records) == 13 and all(r['evidence_ok'] for r in records), records
    (out / 'quick-audit.json').write_text(json.dumps(records, ensure_ascii=False, indent=2), encoding='utf-8')
    print('Quick final evidence:', len(records), 'games;', sum(r['assertions'] for r in records), 'assertions; all consistent')
print('Source differences:', diffs, 'GD lines:', lines)
for r in summary['results']:
    print(r.get('case', 'quick-120'), 'exit', r['exit'], 'passed', r.get('passed'), 'leak', r.get('leak'))
