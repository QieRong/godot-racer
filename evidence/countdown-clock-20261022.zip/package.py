from pathlib import Path
import hashlib
import json
from zipfile import ZipFile, ZIP_DEFLATED

out = Path(__file__).resolve().parent
repo = out.parent.parent
target = repo / 'evidence/countdown-clock-20261022.zip'
if target.exists():
    raise SystemExit('Refusing to overwrite evidence ZIP')
files = {p.name: p.read_bytes() for p in out.iterdir()
         if p.is_file() and p.suffix in ('.py', '.json', '.log', '.txt')}
for name in ('plan/countdown-clock-diagnosis-20261022.md',
             'HANDOVER-2026-10-22-CLOCK-DIAGNOSIS.md',
             'godot-racer/tests/countdown_scene_test.gd'):
    files[name] = (repo / name).read_bytes()
old = repo / 'godot-logs/exit-drain-20261021'
for name in ('snapshot-countdown_scene_test-120.log',
             'snapshot-countdown_scene_test-120.result.json', 'snapshot-source-audit.json'):
    files['historical/' + name] = (old / name).read_bytes()
manifest = ''.join(hashlib.sha256(data).hexdigest() + '  ' + name + '\n'
                   for name, data in sorted(files.items()))
with ZipFile(target, 'w', ZIP_DEFLATED) as archive:
    for name, data in sorted(files.items()):
        archive.writestr(name, data)
    archive.writestr('MANIFEST.sha256', manifest)
with ZipFile(target) as archive:
    for line in archive.read('MANIFEST.sha256').decode('utf-8').splitlines():
        digest, name = line.split('  ', 1)
        assert hashlib.sha256(archive.read(name)).hexdigest() == digest, name
digest = hashlib.sha256(target.read_bytes()).hexdigest()
target.with_suffix('.zip.sha256').write_text(digest + '  ' + target.name + '\n', encoding='utf-8')
(out / 'package-verification.json').write_text(json.dumps(dict(
    files=len(files), manifest_verified=True, zip_sha256=digest, bytes=target.stat().st_size), indent=2), encoding='utf-8')
print('Verified files:', len(files), 'ZIP bytes:', target.stat().st_size, 'SHA256:', digest)
