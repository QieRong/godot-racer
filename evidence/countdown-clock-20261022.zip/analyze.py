"""Describe measured data; no replacement acceptance gate is introduced."""
import hashlib
import json
from pathlib import Path
import re
from zipfile import ZipFile

out = Path(__file__).resolve().parent
repo = out.parent.parent
results = []
for path in sorted(out.glob('*.result.json')):
    result = json.loads(path.read_text(encoding='utf-8'))
    raw = (out / (result['case'] + '.console.log')).read_text(encoding='utf-8')
    samples = [json.loads(line.split(' ', 1)[1]) for line in raw.splitlines()
               if line.startswith('COUNTDOWN_CLOCK_SAMPLE ')]
    windows = [json.loads(line.split(' ', 1)[1]) for line in raw.splitlines()
               if line.startswith('COUNTDOWN_CLOCK_WINDOW ')]
    if samples:
        window = [s for s in samples if s['stage'] == 'window']
        spans = [(b['wall_us'] - a['wall_us']) / 1000000 for a, b in zip(window, window[1:])]
        go = [s for s in samples if s['stage'] == 'go'][0]
        description = dict(
            samples=len(samples), window_samples=len(window),
            window_indices=[s['index'] for s in window],
            window_process_frames=window[-1]['process_frame'] - window[0]['process_frame'],
            window_physics_frames=window[-1]['physics_frame'] - window[0]['physics_frame'],
            wall_step_min_s=min(spans), wall_step_max_s=max(spans),
            lap_monotonic=all(b['lap_s'] >= a['lap_s'] for a, b in zip(samples, samples[1:])),
            lap_origin_values_s=sorted(set(s['lap_origin_s'] for s in samples)),
            lap_origin_equals_go=all(s['lap_origin_s'] == go['go_ms'] / 1000 for s in samples),
            phases=sorted(set(s['phase'] for s in samples)),
            tree_paused_values=sorted(set(s['paused'] for s in samples)),
            paused_ms_values=sorted(set(s['paused_ms'] for s in samples)),
            pause_started_ms_values=sorted(set(s['pause_started_ms'] for s in samples)),
            crossed_values=sorted(set(s['crossed'] for s in samples)),
            laps_done_values=sorted(set(s['laps_done'] for s in samples)),
            lap_vs_wall_error_s=windows[0]['lap_delta_s'] - windows[0]['wall_delta_s'],
            sampling_cost_max_us=max(s['wall_us']-s['wall_before_us'] for s in samples),
            windows=windows)
        (out / (result['case'] + '.samples.json')).write_text(
            json.dumps(samples, ensure_ascii=False, indent=2), encoding='utf-8')
        result['measurements'] = description
    results.append(result)

# Byte comparison to original archive: only the explicitly instrumented test may differ.
differences = []
count = 0
with ZipFile(repo / 'godot-logs/exit-drain-20261021/source-snapshot.zip') as archive:
    for name in archive.namelist():
        if name.startswith('godot-racer/') and not name.endswith('/'):
            count += 1
            actual = out / 'source-snapshot' / name
            if actual.read_bytes() != archive.read(name):
                differences.append(name)
line_debt = []
for path in (repo / 'godot-racer').rglob('*.gd'):
    if any(p in ('.godot', 'addons') for p in path.parts):
        continue
    lines = len(path.read_text(encoding='utf-8-sig').splitlines())
    if lines > 1000:
        line_debt.append(dict(path=str(path.relative_to(repo)), lines=lines))
summary = dict(
    source_base='8e2de4d821b7bbbae6dbde2f049143cbc449a352',
    current_head_at_start='9c3bd657cbbb93eadcf4af776f300b2adea7a5a3',
    snapshot_file_count=count, snapshot_source_differences=differences,
    changed_test_sha256=hashlib.sha256((repo / 'godot-racer/tests/countdown_scene_test.gd').read_bytes()).hexdigest(),
    changed_test_lines=len((repo / 'godot-racer/tests/countdown_scene_test.gd').read_text(encoding='utf-8').splitlines()),
    global_line_debt=line_debt, results=results)
(out / 'analysis.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
for r in results:
    print(r['case'], 'exit=', r['exit'], 'runner_pass=', r['passed'], 'leak=', r['leak'])
    if 'measurements' in r:
        print(json.dumps(r['measurements'], ensure_ascii=False))
print('SOURCE DIFFERENCES', differences, 'LINES', summary['changed_test_lines'], 'DEBT', line_debt)
