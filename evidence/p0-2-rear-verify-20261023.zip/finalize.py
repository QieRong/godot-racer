"""Freeze and read-back-verify this local evidence archive, without publishing."""
from pathlib import Path
import hashlib
import json
import zipfile

out = Path(__file__).resolve().parent
sha = lambda b: hashlib.sha256(b).hexdigest()
audit = json.loads((out / 'source-after-audit.json').read_text(encoding='utf-8'))
assert audit['original_checkout_unchanged']
setup = json.loads((out / 'setup.json').read_text(encoding='utf-8'))
runs = {}
for name in ['baseline-rear-60-red', 'candidate-rear-60-candidate', 'candidate-rear-120-candidate']:
    d = json.loads((out / (name + '.result.json')).read_text(encoding='utf-8'))
    assert d['source_test_sha256'] == setup['test_sha256']
    assert not d['timeout']
    expected = (1, [['0', '1']]) if name.startswith('baseline') else (0, [['24', '0']])
    assert (d['exit'], d['summaries']) == expected
    assert not [p for p in d['snapshot_byte_drift'] if not p.endswith('.import')]
    runs[name] = {k: d[k] for k in ['exit', 'timeout', 'summaries', 'errors', 'warnings', 'source_test_sha256']}
summary = {'task': 'P0-2-REAR-VERIFY-001', 'head': setup['head'],
           'scope': 'same original rear assertions, isolated HEAD-derived candidate only',
           'runs': runs, 'original_checkout_unchanged': True,
           'no_error_or_warning_runtime': False, 'U': 'not tested',
           'commit_or_push_performed': False, 'production_candidate': setup['production_paths']}
summary_path = out / 'SUMMARY.json'
assert not summary_path.exists()
summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
entries = {p.name: p.read_bytes() for p in out.iterdir() if p.is_file()
           and not p.name.endswith(('.zip', '.sha256'))}
for variant in ['baseline', 'candidate']:
    for rel in setup['production_paths'] + setup['test_materials_unmodified']:
        path = out / variant / 'godot-racer' / rel
        assert sha(path.read_bytes()) == setup['snapshots'][variant][rel]
        entries[variant + '-source/' + rel] = path.read_bytes()
manifest = ''.join(sha(raw) + '  ' + name + '\n' for name, raw in sorted(entries.items()))
package = out / 'p0-2-rear-verify-20261023.zip'
assert not package.exists()
with zipfile.ZipFile(package, 'w', zipfile.ZIP_DEFLATED) as z:
    for name, raw in sorted(entries.items()):
        z.writestr(name, raw)
    z.writestr('MANIFEST.sha256', manifest.encode('utf-8'))
with zipfile.ZipFile(package) as z:
    names = set()
    for line in z.read('MANIFEST.sha256').decode().splitlines():
        expected, name = line.split('  ', 1)
        assert sha(z.read(name)) == expected
        names.add(name)
    assert set(z.namelist()) == names | {'MANIFEST.sha256'}
archive_sha = sha(package.read_bytes())
(out / (package.name + '.sha256')).write_text(archive_sha + '  ' + package.name + '\n', encoding='utf-8')
result = {'archive': str(package), 'sha256': archive_sha,
          'manifest_verified_entries': len(names), 'archive_bytes': package.stat().st_size}
(out / 'archive-verification.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(result, ensure_ascii=False))
