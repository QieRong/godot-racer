"""Isolated P0-2 rear candidate verification; never edits the source checkout."""
import argparse
import difflib
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import time
import zipfile

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
ENGINE = Path('E:/godot/Godot_v4.4.1-stable_win64_console.exe')
PRODUCTION = ['project.godot', 'scripts/chase_camera.gd', 'scripts/menu_overlay.gd']
MATERIALS = ['tests/menu_interactions_test.gd', 'tests/menu_interactions_test.gd.uid',
             'tests/interaction_capture.gd', 'tests/interaction_capture.gd.uid']


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def save(name, data):
    path = OUT / name
    if path.exists():
        raise RuntimeError('Refusing to overwrite evidence: ' + str(path))
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')


def checkout_state():
    names = set(git('ls-files', '-z').split(b'\0'))
    names.update(git('ls-files', '--others', '--exclude-standard', '-z').split(b'\0'))
    hashes = {}
    for raw in sorted(names - {b''}):
        name = raw.decode('utf-8')
        path = ROOT / name
        hashes[name] = digest(path.read_bytes()) if path.is_file() else 'MISSING'
    return {'head': git('rev-parse', 'HEAD').decode().strip(),
            'status': git('status', '--porcelain=v1', '--untracked-files=all').decode(),
            'staged': git('diff', '--cached', '--name-only').decode(), 'hashes': hashes}


def prepare():
    save('source-before.json', checkout_state())
    archive = git('archive', '--format=zip', 'HEAD', 'godot-racer')
    archive_hash = digest(archive)
    originals = {}
    for variant in ['baseline', 'candidate']:
        target = OUT / variant
        target.mkdir()
        with zipfile.ZipFile(io.BytesIO(archive)) as z:
            for item in z.infolist():
                resolved = (target / item.filename).resolve()
                if not resolved.is_relative_to(target.resolve()):
                    raise RuntimeError('Unsafe archive path')
            z.extractall(target)
        (target / 'godot-logs').mkdir()
        project = target / 'godot-racer'
        for rel in MATERIALS:
            (project / rel).write_bytes((ROOT / 'godot-racer' / rel).read_bytes())
        if variant == 'candidate':
            for rel in PRODUCTION[:2]:
                (project / rel).write_bytes((ROOT / 'godot-racer' / rel).read_bytes())
            rel = PRODUCTION[2]
            base = (project / rel).read_text(encoding='utf-8-sig')
            current = (ROOT / 'godot-racer' / rel).read_text(encoding='utf-8-sig')
            line = next(x for x in current.splitlines(True) if '_binding("camera_rear", "C")' in x)
            anchor = next(x for x in base.splitlines(True) if '_binding("reset", "R")' in x)
            assert base.count(anchor) == 1
            (project / rel).write_bytes(base.replace(anchor, anchor + line, 1).encode('utf-8'))
        originals[variant] = {p.relative_to(project).as_posix(): digest(p.read_bytes())
                               for p in project.rglob('*') if p.is_file()}
    before = OUT / 'baseline/godot-racer'
    after = OUT / 'candidate/godot-racer'
    diffs = []
    for rel in PRODUCTION:
        diffs.extend(difflib.unified_diff(
            (before / rel).read_text(encoding='utf-8-sig').splitlines(True),
            (after / rel).read_text(encoding='utf-8-sig').splitlines(True),
            fromfile='HEAD/godot-racer/' + rel, tofile='candidate/godot-racer/' + rel))
    (OUT / 'production-candidate.patch').write_bytes(''.join(diffs).encode('utf-8'))
    test = (after / 'tests/menu_interactions_test.gd').read_bytes()
    assert test == (before / 'tests/menu_interactions_test.gd').read_bytes()
    project_before = (before / 'project.godot').read_text(encoding='utf-8-sig')
    project_after = (after / 'project.godot').read_text(encoding='utf-8-sig')
    assert re.sub(r'camera_rear=\{\n.*?\n\}\n', '', project_after, flags=re.S) == project_before
    save('setup.json', {'task': 'P0-2-REAR-VERIFY-001', 'head': git('rev-parse', 'HEAD').decode().strip(),
                       'archive_sha256': archive_hash, 'production_paths': PRODUCTION,
                       'test_materials_unmodified': MATERIALS, 'test_sha256': digest(test),
                       'source_bytes': 'HEAD Git archive blob bytes plus the three listed candidate changes',
                       'gates_modified': False, 'snapshots': originals})
    print('PREPARED', OUT, flush=True)


def run(variant, stage, fps, tag):
    project = OUT / variant / 'godot-racer'
    name = f'{variant}-{stage}' + (f'-{fps}' if stage == 'rear' else '')
    if tag:
        if not re.fullmatch(r'[a-z0-9-]+', tag):
            raise ValueError('Unsafe run tag')
        name += '-' + tag
    if (OUT / (name + '.result.json')).exists():
        raise RuntimeError('Run already exists: ' + name)
    engine_log = OUT / (name + '.engine.log')
    command = [str(ENGINE), '--path', str(project), '--headless', '--log-file', str(engine_log)]
    if stage == 'import':
        command += ['--recovery-mode', '--import']
        timeout = 90
    elif stage == 'lint':
        command = ['pwsh', '-NoProfile', '-File', str(ROOT / '04-Godot启动器/lint-gdscript.ps1'),
                   '-Path', str(project)]
        timeout = 29
    else:
        command += ['--script', 'res://tests/menu_interactions_test.gd', '--',
                    '--interaction=rear', f'--render-fps={fps}']
        timeout = 29
    started = time.monotonic()
    timed_out = False
    env = os.environ.copy()
    for key, rel in [('APPDATA', 'roaming'), ('LOCALAPPDATA', 'local'), ('TEMP', 'tmp'), ('TMP', 'tmp')]:
        directory = OUT / variant / 'runtime-profile' / rel
        directory.mkdir(parents=True, exist_ok=True)
        env[key] = str(directory)
    try:
        proc = subprocess.run(command, capture_output=True, timeout=timeout, cwd=OUT / variant, env=env)
        stdout, stderr, code = proc.stdout, proc.stderr, proc.returncode
    except subprocess.TimeoutExpired as exc:
        stdout, stderr, code = exc.stdout or b'', exc.stderr or b'', 124
        timed_out = True
    (OUT / (name + '.stdout.log')).write_bytes(stdout)
    (OUT / (name + '.stderr.log')).write_bytes(stderr)
    raw = engine_log.read_bytes() if engine_log.exists() else stdout + stderr
    log = raw.decode('utf-8', errors='replace')
    summaries = re.findall(r'INTERACTION_DONE KIND=rear PASS=(\d+) FAIL=(\d+)', log)
    errors = [l for l in log.splitlines() if 'ERROR:' in l or 'SCRIPT ERROR' in l]
    warnings = [l for l in log.splitlines() if 'WARNING:' in l or 'Unreferenced static string' in l]
    setup = json.loads((OUT / 'setup.json').read_text(encoding='utf-8'))
    initial = setup['snapshots'][variant]
    drift = [rel for rel, sha in initial.items()
             if not (project / rel).is_file() or digest((project / rel).read_bytes()) != sha]
    result = {'command': command, 'exit': code, 'timeout': timed_out,
              'isolated_environment': {k: env[k] for k in ['APPDATA', 'LOCALAPPDATA', 'TEMP', 'TMP']},
              'seconds': round(time.monotonic() - started, 3), 'summaries': summaries,
              'errors': errors, 'warnings': warnings, 'snapshot_byte_drift': drift,
              'source_test_sha256': digest((project / 'tests/menu_interactions_test.gd').read_bytes()),
              'scope': 'original rear assertions; no acceptance changes; warnings reported separately'}
    save(name + '.result.json', result)
    print(json.dumps({'name': name, **result}, ensure_ascii=False), flush=True)


def audit():
    before = json.loads((OUT / 'source-before.json').read_text(encoding='utf-8'))
    after = checkout_state()
    changed = [p for p in sorted(set(before['hashes']) | set(after['hashes']))
               if before['hashes'].get(p) != after['hashes'].get(p)]
    result = {'original_checkout_unchanged': before == after, 'changed_paths': changed,
              'head_unchanged': before['head'] == after['head'],
              'status_unchanged': before['status'] == after['status'],
              'staged_unchanged': before['staged'] == after['staged']}
    save('source-after-audit.json', result)
    print(json.dumps(result, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['prepare', 'run', 'audit'])
    parser.add_argument('--variant', choices=['baseline', 'candidate'], default='candidate')
    parser.add_argument('--stage', choices=['lint', 'import', 'rear'], default='rear')
    parser.add_argument('--fps', type=int, choices=[60, 120], default=60)
    parser.add_argument('--tag', default='')
    args = parser.parse_args()
    if args.action == 'prepare': prepare()
    elif args.action == 'audit': audit()
    else: run(args.variant, args.stage, args.fps, args.tag)
