extends SceneTree
## 实际关卡后视截图/首页输入路由取证；29秒看门狗，不是长回归或真人U。
## --capture-kind=rear|showcase --capture-size=1366x705

var _kind := "rear"
var _size := Vector2i(1366, 705)
var _gs: Node
var _view: SubViewport
var _scene: Node
var _display: Control
var _stage := 0
var _frames := 0
var _elapsed := 0.0
var _scheduled := false
var _fail := 0
var _samples: Array[float] = []
var _hover_angle := 0.0


func _initialize() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--capture-kind="):
			_kind = arg.get_slice("=", 1)
		if arg.begins_with("--capture-size="):
			var dimensions := arg.get_slice("=", 1).split("x")
			_size = Vector2i(int(dimensions[0]), int(dimensions[1]))
	call_deferred("_boot")


func _boot() -> void:
	_gs = root.get_node("GameState")
	_gs.settings_path = ProjectSettings.globalize_path("res://../godot-logs/interaction-capture-settings.cfg")
	# 本机屏高不足1080：物理窗口保持可容纳尺寸，1920画布在独立视口离屏验证。
	root.size = Vector2i(1366, 705)
	_view = SubViewport.new()
	_view.size = _size
	_view.own_world_3d = true
	_view.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	root.add_child(_view)
	if _kind == "rear":
		_gs.chosen_level = 0
		_scene = load("res://scenes/main.tscn").instantiate()
		_view.add_child(_scene)
	else:
		_scene = load("res://scripts/menu.gd").new()
		_view.add_child(_scene)
		_display = _scene.find_child("HomeCarShowcase", true, false)


func _process(delta: float) -> bool:
	_elapsed += delta
	_frames += 1
	if _elapsed >= 28:
		print("CAPTURE_TIMEOUT KIND=%s" % _kind)
		quit(2)
		return false
	if _view == null or _scheduled:
		return false
	if _kind == "rear":
		if not bool(_scene.get("_setup_done")) or _gs.call("phase_name") != "RACING":
			return false
		if _frames % 4 == 0:
			_capture_rear()
	else:
		_capture_showcase(delta)
	return false


func _check(ok: bool, message: String) -> void:
	print("CAPTURE_ASSERT %s %s" % ["PASS" if ok else "FAIL", message])
	if not ok:
		_fail += 1


func _capture_rear() -> void:
	if _stage >= 6:
		_finish()
		return
	var camera: Camera3D = _scene.find_child("ChaseCamera", true, false)
	var mode := _stage / 2
	Input.action_release("camera_rear")
	var release := InputEventKey.new()
	release.physical_keycode = KEY_C
	_view.push_input(release)
	camera.set_view_mode(mode)
	var rear := _stage % 2 == 1
	if rear:
		var key := InputEventKey.new()
		key.physical_keycode = KEY_C
		key.pressed = true
		Input.action_press("camera_rear")
		_view.push_input(key)
	_check(bool(camera.get("_rear_held")) == rear, "真实关卡相机C状态 mode=%d rear=%s" % [mode, rear])
	var direction := -camera.global_basis.z
	var target: Node3D = camera.target
	if rear:
		_check(direction.dot(target.global_basis.z.normalized()) > 0.8, "真实关卡镜头向后")
	_save("mode%d-%s" % [mode, "rear" if rear else "forward"])
	_stage += 1


func _mouse_motion(position: Vector2, relative := Vector2.ZERO) -> void:
	var motion := InputEventMouseMotion.new()
	motion.position = position
	motion.global_position = position
	motion.relative = relative
	_view.push_input(motion, true)


func _mouse_button(position: Vector2, pressed: bool) -> void:
	var button := InputEventMouseButton.new()
	button.position = position
	button.global_position = position
	button.button_index = MOUSE_BUTTON_LEFT
	button.pressed = pressed
	_view.push_input(button, true)


func _capture_showcase(delta: float) -> void:
	var center := _display.get_global_rect().get_center()
	var outside := Vector2(_size.x - 8, center.y)
	match _stage:
		0:
			if _elapsed < 0.7:
				return
			_mouse_motion(Vector2(10, 10))
			print("SHOWCASE_STATE stage=auto angle=%f hovered=%s suspended=%s focused=%s" % [
				_display.angle, _display.hovered, _display.suspended, _display.get("_focused")])
			_display.set_angle(0.0)
			_save("auto-start")
			_stage = 1
		1:
			_samples.append(delta * 1000.0)
			if _elapsed < 1.7:
				return
			_check(_display.angle > deg_to_rad(8), "真实渲染自转推进")
			_save("auto-rotated")
			_mouse_motion(center)
			_hover_angle = _display.angle
			_stage = 2
		2:
			if _elapsed < 2.1:
				return
			print("SHOWCASE_STATE stage=hover angle=%f expected=%f hovered=%s suspended=%s focused=%s" % [
				_display.angle, _hover_angle, _display.hovered, _display.suspended, _display.get("_focused")])
			_check(_display.hovered and is_equal_approx(_display.angle, _hover_angle), "真实鼠标路由hover停止")
			_save("hover-paused")
			_mouse_button(center, true)
			_mouse_motion(outside, Vector2(120, 0))
			_stage = 3
		3:
			if _elapsed < 2.4:
				return
			_check(_display.dragging and _display.angle > _hover_angle + deg_to_rad(10), "真实路由拖动移出仍控制")
			_save("drag-outside")
			_mouse_button(outside, false)
			_stage = 4
		4:
			if _elapsed < 2.7:
				return
			_check(not _display.dragging, "真实路由区域外松开")
			_scene.call("_open_overlay", "help", _scene.get("_home").controls()[2])
			_check(_display.suspended, "真实页面打开帮助停展车")
			_save("overlay-suspended")
			_stage = 5
		5:
			_scene.call("_close_overlay")
			_samples.sort()
			if not _samples.is_empty():
				print("SHOWCASE_FRAME_MS samples=%d p50=%.3f p95=%.3f renderer=%s" % [
					_samples.size(), _samples[_samples.size() / 2], _samples[int(_samples.size() * 0.95)], RenderingServer.get_video_adapter_name()])
			_finish()


func _save(label: String) -> void:
	_scheduled = true
	RenderingServer.frame_post_draw.connect(func():
		var output := ProjectSettings.globalize_path("res://../godot-logs/interaction-%s-%s-%dx%d.png" % [_kind, label, _size.x, _size.y])
		var error := _view.get_texture().get_image().save_png(output)
		print("CAPTURE_SAVE=%d PATH=%s" % [error, output])
		if error != OK:
			_fail += 1
		_scheduled = false
	, CONNECT_ONE_SHOT)


func _finish() -> void:
	if _stage == 99:
		return
	_stage = 99
	_scheduled = true
	Input.action_release("camera_rear")
	var music := _gs.find_child("MenuMusic", false, false)
	if music != null:
		music.shutdown()
		await create_timer(0.15, true, false, true).timeout
	print("CAPTURE_DONE KIND=%s FAIL=%d" % [_kind, _fail])
	quit(0 if _fail == 0 else 1)
