from pathlib import Path
import hashlib, json, zipfile
root = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent
for name in ("contract-ready", "integration-ready", "validation-ready", "docs-final", "readme-final"):
    result = json.loads((out / (name + ".result.json")).read_text(encoding="utf-8"))
    assert result["exit"] == 0 and not result["timeout"]
excluded = {"check-ui-pages-before.py.txt", "check-ui-pages.proposed.py", "test-proposed.py",
            "archive-audit.json", "publish-receipt.json", "staged-audit.json", "staged-diff.patch"}
items = {p.name: p.read_bytes() for p in out.iterdir()
         if p.is_file() and p.name not in excluded and p.suffix != ".pyc"}
for name in ("godot-racer/tests/menu_uid_guard_test.py", "godot-racer/tests/menu_uid_guard_integration_test.py",
             "plan/ui-uid-guard-20261023.md", "godot-racer/docs/testing.md",
             "HANDOVER-2026-10-23-UID-GUARD-PAUSE.md"):
    items["published/" + name] = (root / name).read_bytes()
items["README.txt"] = ("UID guard evidence. checker-index.py is the exact scoped checker candidate.\n"
    "Working UI checker source is recorded by hash only; pre-existing UI source/assets are not published.\n"
    "Original/draft and failed staging-audit receipts are retained.\n"
    "See plan for exact test subjects and limits. This is not a standalone game rebuild.\n").encode()
manifest = "".join(hashlib.sha256(data).hexdigest() + "  " + name + "\n" for name, data in sorted(items.items()))
items["MANIFEST.sha256"] = manifest.encode()
archive = root / "evidence/ui-uid-guard-20261023.zip"
assert not archive.exists(), "Do not overwrite evidence"
with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as package:
    for name, data in sorted(items.items()):
        package.writestr(name, data)
with zipfile.ZipFile(archive) as package:
    assert package.testzip() is None
    assert len(package.namelist()) == len(set(package.namelist())) == len(items)
    for line in package.read("MANIFEST.sha256").decode().splitlines():
        digest, name = line.split("  ", 1)
        assert hashlib.sha256(package.read(name)).hexdigest() == digest, name
sha = hashlib.sha256(archive.read_bytes()).hexdigest()
archive.with_suffix(".zip.sha256").write_bytes((sha + "  " + archive.name + "\n").encode())
audit = dict(archive=str(archive), sha256=sha, entries=len(items), verified_entries=len(items)-1,
             zip_crc_ok=True, each_manifest_entry_verified=True)
(out / "archive-audit.json").write_text(json.dumps(audit, indent=2), encoding="utf-8")
print(json.dumps(audit, ensure_ascii=False))
