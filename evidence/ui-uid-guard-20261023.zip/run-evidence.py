from pathlib import Path
import hashlib, json, os, subprocess, sys, time
sys.stdout.reconfigure(encoding="utf-8")
root = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent
name, *command = sys.argv[1:]
assert name and command
assert not (out / (name + ".result.json")).exists(), "Use a new evidence name"
env = dict(os.environ, PYTHONIOENCODING="utf-8")
start = time.perf_counter()
with (out / (name + ".stdout.log")).open("wb") as stdout, (out / (name + ".stderr.log")).open("wb") as stderr:
    process = subprocess.Popen(command, cwd=root, stdout=stdout, stderr=stderr, env=env)
    timeout = False
    try:
        code = process.wait(timeout=120)
    except subprocess.TimeoutExpired:
        timeout = True
        process.kill()
        code = process.wait()
receipt = dict(command=command, pid=process.pid, exit=code, timeout=timeout, wall_s=time.perf_counter()-start,
               source_sha256={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in
                ["godot-racer/tests/check-ui-pages.py", "godot-racer/tests/menu_uid_guard_test.py"]})
(out / (name + ".result.json")).write_text(json.dumps(receipt, indent=2, ensure_ascii=False), encoding="utf-8")
print((out / (name + ".stdout.log")).read_text(encoding="utf-8", errors="replace"))
print((out / (name + ".stderr.log")).read_text(encoding="utf-8", errors="replace"))
print(json.dumps(receipt, ensure_ascii=False))
raise SystemExit(code if not timeout else 124)
