extends SceneTree
func _initialize() -> void:
    for text in ["uid://cmenu0000000001", "uid://dqocqawofnujo", "uid://dpi8hmjv8cegm"]:
        var id := ResourceUID.text_to_id(text)
        print("UID_PROBE text=%s id=%d canonical=%s" % [text, id, ResourceUID.id_to_text(id)])
    print("UID_PROBE scene_resource=%d" % ResourceLoader.get_resource_uid("res://scenes/menu.tscn"))
    quit()
