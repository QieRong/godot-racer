UID guard evidence. checker-index.py is the exact scoped checker candidate.
Working UI checker source is recorded by hash only; pre-existing UI source/assets are not published.
Original/draft and failed staging-audit receipts are retained.
See plan for exact test subjects and limits. This is not a standalone game rebuild.
