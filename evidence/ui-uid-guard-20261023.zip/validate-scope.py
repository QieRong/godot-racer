from pathlib import Path
import ast, difflib, hashlib, json, py_compile, subprocess
root = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent
working = (root / "godot-racer/tests/check-ui-pages.py").read_text(encoding="utf-8")
original = (out / "check-ui-pages-before.py.txt").read_text(encoding="utf-8")
base = (out / "checker-head.py.txt").read_text(encoding="utf-8")
candidate = (out / "checker-index.py").read_text(encoding="utf-8")
helper = working[working.index("def menu_uid_metadata_only("):working.index("protected = [")]
new_gate = working[working.index("changed = subprocess.run("):working.index("# INT-02公开允许")].rstrip("\n")
old_gate = 'check("CD-01", diff.returncode == 0, "物理/AI/场景/发车与状态机无diff")'
assert working.replace(helper, "", 1).replace(new_gate, old_gate, 1) == original
assert candidate.replace(helper, "", 1).replace(new_gate, old_gate, 1) == base
assert (root / "godot-racer/scenes/menu.tscn").read_bytes() == (out / "menu-before.tscn").read_bytes()
assert subprocess.check_output(["git", "show", "HEAD:godot-racer/tests/check-ui-pages.py"], cwd=root) == (out / "checker-head.py.txt").read_bytes()
red = json.loads((out / "contract-red.result.json").read_text(encoding="utf-8"))
green = json.loads((out / "contract-green.result.json").read_text(encoding="utf-8"))
assert red["exit"] == 1 and green["exit"] == 0
assert red["source_sha256"]["godot-racer/tests/menu_uid_guard_test.py"] == green["source_sha256"]["godot-racer/tests/menu_uid_guard_test.py"]
for name, summary in [("contract-green", "UID_CONTRACT_SUMMARY pass=20 fail=0"),
                      ("contract-index", "UID_CONTRACT_SUMMARY pass=20 fail=0"),
                      ("integration-final", "UID_INTEGRATION_SUMMARY pass=9 fail=0"),
                      ("source-green", "UI_SOURCE_DONE PASS=61 FAIL=0")]:
    receipt = json.loads((out / (name + ".result.json")).read_text(encoding="utf-8"))
    assert receipt["exit"] == 0 and not receipt["timeout"]
    assert (out / (name + ".stdout.log")).read_text(encoding="utf-8").count(summary) == 1
    assert not (out / (name + ".stderr.log")).read_bytes()
for name in ("source-red", "proposed-source", "proposed-contract", "docs-final", "readme-final"):
    receipt = json.loads((out / (name + ".result.json")).read_text(encoding="utf-8"))
    assert receipt["exit"] == (1 if name == "source-red" else 0)
for path in [root / "godot-racer/tests/check-ui-pages.py", out / "checker-index.py",
             root / "godot-racer/tests/menu_uid_guard_test.py", root / "godot-racer/tests/menu_uid_guard_integration_test.py"]:
    ast.parse(path.read_text(encoding="utf-8"))
    py_compile.compile(str(path), cfile=str(out / (path.name + ".pyc")), doraise=True)
    print("PYTHON_COMPILE PASS " + path.name)
subprocess.run(["git", "diff", "--check", "--", "godot-racer/tests/check-ui-pages.py", "godot-racer/docs/testing.md"], cwd=root, check=True)
patch = "".join(difflib.unified_diff(base.splitlines(True), candidate.splitlines(True),
                                   "a/godot-racer/tests/check-ui-pages.py", "b/godot-racer/tests/check-ui-pages.py"))
(out / "staged-only.patch").write_text(patch, encoding="utf-8")
files = ["godot-racer/tests/check-ui-pages.py", "godot-racer/tests/menu_uid_guard_test.py",
         "godot-racer/tests/menu_uid_guard_integration_test.py", "godot-racer/scenes/menu.tscn",
         "godot-racer/project.godot", "godot-racer/docs/testing.md", "plan/ui-uid-guard-20261023.md",
         "HANDOVER-2026-10-23-UID-GUARD-PAUSE.md"]
audit = dict(working_delta_exact=True, candidate_delta_exact=True, menu_bytes_unchanged=True,
             contract_red_green_same_source=True, candidate_sha256=hashlib.sha256(candidate.encode()).hexdigest(),
             files={p: hashlib.sha256((root / p).read_bytes()).hexdigest() for p in files})
(out / "scope-audit.json").write_text(json.dumps(audit, indent=2), encoding="utf-8")
print("SCOPE_AUDIT PASS approved_delta_only / original_UI_diff_preserved / menu_unchanged / same_red_green_test")
