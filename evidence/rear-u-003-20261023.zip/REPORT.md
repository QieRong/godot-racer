# REAR-U-003：隔离候选体验验收准备与证据归档

日期：2026-10-23（Asia/Shanghai）。状态：真人 U 未验；仅证据归档并推送后暂停。

## 授权与结论边界

用户批准先使用现有 green 隔离工程安排真人 U，生产修改文件为 0，新增证据限 `godot-logs/rear-u-003-20261023/`；随后明确反馈：“现在不便操作，U保持未验后归档推送”。本次发布仅本计划、暂停交接、证据 ZIP 及 SHA256 共四个文件，不应用相机修复，不提交原工作区其他差异。

基线 HEAD、本地 origin/main、开工实时远端 main 均为 `1b28e4f6b2be7a7686836dacb88fc60ff6072b24`。原现场为 17 修改、2 删除、50 未跟踪，暂存区为空。原相机为 299 行，SHA256=`5e52b5ef0105db601115735a5e5774b093dd483b494d926a3a2233e8c1211fbc`。

## 本轮执行范围

- 启动目标仅 `godot-logs/rear-boundary-002-20261023/green/godot-racer/`，入口沿用该工程的菜单场景；没有改变工程配置、脚本、测试或资产。
- Godot 4.4.1，普通图形启动，Forward+、NVIDIA GeForce 920MX；命令指定 `--render-fps=60`，日志报告 1280×720、物理 120 Hz、五关配置加载。
- APPDATA、LOCALAPPDATA、TEMP、TMP 全部重定向到本轮新证据目录的 profile；原编辑器和其他游戏不操作、不关闭。
- 两次启动分别使用 `--quit-after 5400` 和 `--quit-after 3600`。第二次显式指定显示窗口。完整命令、PID、时间、退出码和超时字段分别见 `gui-start.json` / `gui-result.json` 与 `visible-gui-start.json` / `visible-gui-result.json`。
- `sky.list_windows` 多次未返回本轮新游戏窗口，未获取截图或录像。窗口发现记录在 ZIP 中保留；不能把启动日志、帧数退出或 exit0 解释为页面已显示、GUI 可用或真人验收。
- 根证书 `ERROR: Failed to read the root certificate store.` 原样保留；其他错误、警告和最终进程状态以原始日志及 `observation-summary.json` 为准。

两次启动最终均 exit0、未超时，分别耗时125.156秒和67.516秒，均由预设帧数结束；原始日志无 SCRIPT ERROR 或 WARNING，但都有根证书 ERROR。此结果只证明这两次启动进程正常结束，不证明窗口画面可用。

没有发送驾驶、后视、切换视角、环视或窗口切换输入。没有帮助页面排版、五关驾驶、真实窗口失焦、备用 UP 边界连续滚转的实测证据。本轮不补写这些项目的 PASS。

## 继承的专项证据

REAR-BOUNDARY-002 的正式红绿属于此前隔离测试，本轮未重跑：未修复候选竖直 163/163，但 36 次共线 WARNING，Godot exit0、验收 exit1，仍算红。修复候选 60/120 FPS 各为状态 114、竖直 163、原后视 24，共 301 条；根证书 ERROR 保留。

修复候选相机为 306 行，SHA256=`86f54d3d0162eba724bde28be21c2b23485ea520a5dfd5cd32b0f1a4e94bd484`。世界 UP 与 FORWARD 在绝对点积 `0.999` 处分支切换，连续滚转观感仍未验。旧证据 ZIP SHA256=`57b72cead524f63eda384e1cc0e219014da78db6c4642339441064cabaacae5e`。

## 保护、验证与发布白名单

归档前逐项比较开工快照：原 HEAD、完整 status、暂存清单与 676 个路径的 SHA256/缺失状态；另保护上一轮目录中 850 个非缓存/profile文件。结果见本轮 ZIP 中 `source-before.json`、`source-after-audit.json`、`previous-evidence-before.json` 和 `audit.json`。旧 `.godot` 缓存不属于原始证据保护范围，也不带回生产。

本次仅发布：

1. `plan/rear-u-003-20261023.md`
2. `HANDOVER-2026-10-23-REAR-U-PAUSE.md`
3. `evidence/rear-u-003-20261023.zip`
4. `evidence/rear-u-003-20261023.zip.sha256`

文档门使用现有 `check-docs.ps1` / `check-readme.ps1`，不启动 Godot；最终命令、退出码与输出保存在 ZIP。暂存后检查完整白名单、`git diff --cached --check` 及内容哈希。不使用批量暂存、reset、clean、stash；普通 commit/push 后核验 HEAD、本地 origin/main、实时远端 main 和 0/0。

两道文档门本轮均实测 exit0。首次归档编排在文档门通过、日志及收据保存后，向 GBK 控制台打印 Unicode 勾号时报编码错误；未篡改或重跑已过的文档门，仅用 UTF8 控制台补执行尚未运行的 README 门，过程说明单独保留。

ZIP 只包含本轮报告、脚本、日志、收据、保护快照和指定候选源码/继承证据，附逐文件 MANIFEST；不包含完整资产和缓存，不是独立游戏包或完整 Git 工作树。ZIP SHA256 见同名 `.sha256`。最终发布 SHA 见最终回复和本地 `publication-receipt.json`；该收据生成于 ZIP 封存和提交后，不声称包含在 ZIP 内。

## C / T / U 与暂停交接

- C：修复仍只在旧 green 隔离候选；原工作区未应用。
- T：既有相机专项/lint/解析结论不变；本轮仅新增普通图形启动尝试和文档归档检查，未形成 GUI 验收证据。
- U：用户明确暂不操作，全部保持未验。

未执行完整 suite、AC-13、听感、冻结带回放或新导出包。未关闭 P0-2 资产/干净源码发布绑定、历史 phys 或访问冲突。

推送核验完成即暂停。下一对话先只读；如安排真人 U，需实际覆盖三视角 C/V/右键优先级、松开恢复、暂停/退出确认、真实失焦恢复、倒计时按住 C 到 GO，以及备用 UP 切换边界连续画面。边界无法覆盖就继续标未验。原工作区单文件修复的应用仍需单独批准。
