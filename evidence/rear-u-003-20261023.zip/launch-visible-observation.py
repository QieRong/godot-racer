"""GUI startup observation only; never represents human acceptance."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
PROJECT = ROOT / 'godot-logs/rear-boundary-002-20261023/green/godot-racer'
ENGINE = Path('E:/godot/Godot_v4.4.1-stable_win64.exe')


def save(name, data):
    with (OUT / name).open('x', encoding='utf-8') as handle:
        json.dump(data, handle, ensure_ascii=False, indent=2)


env = os.environ.copy()
for key, relative in [('APPDATA', 'roaming'), ('LOCALAPPDATA', 'local'),
                      ('TEMP', 'tmp'), ('TMP', 'tmp')]:
    location = OUT / 'profile' / relative
    location.mkdir(parents=True, exist_ok=True)
    env[key] = str(location)

command = [str(ENGINE), '--path', str(PROJECT), '--log-file',
           str(OUT / 'visible-gui.engine.log'), '--quit-after', '3600',
           '--', '--render-fps=60']
started = time.monotonic()
with (OUT / 'visible-gui.stdout.log').open('xb') as stdout, (OUT / 'visible-gui.stderr.log').open('xb') as stderr:
    startup = subprocess.STARTUPINFO()
    startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    startup.wShowWindow = 1
    process = subprocess.Popen(command, cwd=OUT, env=env, stdout=stdout, stderr=stderr, startupinfo=startup)
    save('visible-gui-start.json', {'command': command, 'pid': process.pid,
                          'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                          'profile': {key: env[key] for key in ['APPDATA', 'LOCALAPPDATA', 'TEMP', 'TMP']},
                          'scope': 'GUI startup observation only; no gameplay or human acceptance',
                          'camera_sha256': hashlib.sha256((PROJECT / 'scripts/chase_camera.gd').read_bytes()).hexdigest()})
    timed_out = False
    try:
        code = process.wait(timeout=180)
    except subprocess.TimeoutExpired:
        timed_out = True
        process.terminate()
        code = process.wait(timeout=15)
    save('visible-gui-result.json', {'exit': code, 'timeout': timed_out,
                            'seconds': round(time.monotonic() - started, 3),
                            'quit_after_frames': 3600, 'U': 'NOT_TESTED',
                            'no_gameplay_input_requested': True})
print('GUI observation process ended', code, 'timeout', timed_out, flush=True)
