# REAR-BOUNDARY-002：相机状态边界与竖直姿态专项

日期：2026-10-23（Asia/Shanghai）。仅本地隔离候选；未应用原工作区、未提交、未推送。

## 授权与基线

用户批准上一轮展示的相机状态规则及新增精确判据，实施限定在隔离候选。仓库 HEAD、本地 origin/main、开工实时远端 main 均为 `1b28e4f6b2be7a7686836dacb88fc60ff6072b24`。原现场为 17 修改、2 删除、50 未跟踪，暂存区为空。

`red/`、`green/` 从当前 HEAD 的 Git archive blob 建立，只加入上轮隔离候选的三文件增量，以及本轮测试材料；没有复制原工作区其他首页、BGM、资产、冻结带或导入缓存。旧证据目录保持原样。本目录被 Git 忽略，不是完整 Git 工作树或发布候选。

## 已批准的状态规则

| 状态 | 相机控制输入 | 常规跟随 |
|---|---|---|
| RACING 且有焦点 | 原 C 后视、V 和右键优先级 | 原算法 |
| LOADING、COUNTDOWN | 忽略 C、V、右键环视 | 继续跟随，COUNTDOWN 树暂停也更新 |
| MENU、PAUSED、FINISHED、EXIT_CONFIRM | 忽略相机控制输入 | 解除后视并恢复一次，随后冻结 |
| 失焦 | 解除后视，忽略相机控制输入 | 恢复一次后冻结 |

返回 RACING 或恢复焦点时不继承旧 C 按住状态，释放后重新按下才可后视。COUNTDOWN→GO 同样不继承倒计时内的 C 按住。此状态门在原候选已存在，本轮经批准锁定行为并补专项，不声称它与 HEAD 所有阶段行为等价。

## 生产候选的最小修复

仅修改 `green/godot-racer/scripts/chase_camera.gd`：299→306 行，符合 ≤1000 行限制。原工作区同名文件仍是 299 行且未改动。

新增 `_look_at_stable()`，在观察方向与世界 UP 的点积绝对值大于 `0.999` 时选世界 FORWARD 为备用 up，否则保持原世界 UP。后视及常规跟随共用该入口；一处注释同步实际状态规则。未改变相机距离、平滑参数、车辆、AI、赛道、比赛相位实现、InputMap、原 24 条断言或源码保护门。

原竖直夹具将车后轴置为 ±世界 UP；原 `_apply_rear()` 的观察方向因此与固定 up 共线。最终日志的阶段标签定位到进入/保持后视。该警告可被稳定复现，但原朝向断言仍通过，不能将它描述为已证明的画面故障。

精确差异：`camera-repair.patch`；修复后相机 SHA256：`86f54d3d0162eba724bde28be21c2b23485ea520a5dfd5cd32b0f1a4e94bd484`。

## 判据和真实结果

新增测试 `rear_boundary_test.gd` 最终 283 行。通过 `Input.parse_input_event` 分发物理 C/V 键和鼠标事件，等待真实节点处理；GameState 的生产相位方法负责建立状态及树暂停。失焦使用引擎 notification 模拟，并非真人窗口切换验收。

- 六个非 RACING 相位 × 三视角，双帧率；忽略输入、冻结变换误差 ≤`1e-5`。
- LOADING/COUNTDOWN 与 HEAD 原相机同目标、同帧 delta 对比，误差 ≤`1e-4`；日志记录的最大误差均为 0。参考相机仅在对照时设 ALWAYS，以验证跟随算法，不表示 HEAD 在暂停树中的调度行为相同。
- 后视中进入 PAUSED/FINISHED/EXIT_CONFIRM、恢复、失焦、COUNTDOWN→GO，验证清理与重新按键。
- 三视角 × 六种竖直/近竖直姿态（±UP 及 ±`1e-4 RIGHT` 扰动），进入/保持/退出；位置与基有限、正交和单位误差 ≤`1e-4`，后视直接对照车后轴且 dot >`0.95`，释放恢复原模式，车辆变换不变。
- 验收层额外要求共线 WARNING 为 0；其他新错误或警告、超时、SCRIPT ERROR、缺失/重复汇总、空计数、断言失败或进程非零均拒绝。根证书 ERROR 单独保留，专项通过不等于零错误运行。

| 最终运行 | 断言 | Godot exit | 验收 exit | 共线警告 |
|---|---:|---:|---:|---:|
| 未修复候选，状态，60 FPS | 114/114 | 0 | 0 | 0 |
| 未修复候选，竖直，60 FPS | 163/163 | 0 | **1** | **36** |
| 修复候选，状态，60 FPS | 114/114 | 0 | 0 | 0 |
| 修复候选，竖直，60 FPS | 163/163 | 0 | 0 | 0 |
| 修复候选，原后视，60 FPS | 24/24 | 0 | 0 | 0 |
| 修复候选，状态，120 FPS | 114/114 | 0 | 0 | 0 |
| 修复候选，竖直，120 FPS | 163/163 | 0 | 0 | 0 |
| 修复候选，原后视，120 FPS | 24/24 | 0 | 0 | 0 |

每档最终 301 条断言，均未超时，无 SCRIPT ERROR、无 WARNING。每次运行仍有 `ERROR: Failed to read the root certificate store.`，所以不是零错误运行。结果不仅依据 exit 0，还核对唯一最终汇总及逐条非空回执。状态门原候选已满足，未伪造这部分的行为失败；红绿由新增的零共线警告要求区分。

红绿最终新测试 SHA256 同为 `5056e8acc854d02a6b55e3d9cfa6f6a48693af83f012b0529f732acb58a81a36`。原 24 条专项源码始终为 `b46325d27ded46f1c66fc8ea792cae7a973239873fff5cb9e1875db3effc18f4`。没有修改或放松原断言。

候选原 lint 实测 exit 0；新增测试 `--check-only` 实测 exit 0；运行时实际加载并执行候选相机。导入两侧均 exit 0，但保留根证书、headless dummy texture ERROR 和缺失 Godot MCP 插件 WARNING，不能算干净导入。

首次测试自带日志曾使用 Godot 不支持的 `%g`，产生格式错误，因此未计入验收。改为 `%f` 后通过；之后补强车后轴独立朝向及 held 检查，将竖直断言由 127 增至 163。三个测试版本均按已有收据哈希核验并保留，见 `test-revisions.json`。初步运行和正式红绿日志均不覆盖；正式红测的验收进程 exit 1 与内部引擎 exit 0 明确分列。

## 复现

所有命令在原仓库根目录执行，目标仅隔离工程。现有 tag 不可覆盖，复跑须换新 tag：

```powershell
python godot-logs/rear-boundary-002-20261023/run.py run --variant red --stage vertical --fps 60 --tag replay-new-red
python godot-logs/rear-boundary-002-20261023/run.py run --variant green --stage state --fps 60 --tag replay-new-state
python godot-logs/rear-boundary-002-20261023/run.py run --variant green --stage vertical --fps 60 --tag replay-new-vertical
python godot-logs/rear-boundary-002-20261023/run.py run --variant green --stage rear --fps 60 --tag replay-new-rear
```

120 FPS 将参数改为 120，仍串行执行。每次 `.result.json` 记录完整命令、真实引擎退出、超时、哈希、错误和警告；外层 Python 的最终退出表示专项验收结果。源码快照不等于完整干净检出验收。

## 保护、状态及未验项

原工作区前后完整 HEAD/status/暂存清单及原已跟踪、未跟踪文件逐文件 SHA256 已核验完全不变，变化路径为空，见 `source-before.json`、`source-after.json`、`audit.json`。隔离两侧各 71 个 `.import` 漂移全部逐个证实仅 CRLF/LF；其余变化仅为有版本记录的新测试，以及绿色候选的相机修复。没有未分类漂移，不带回原现场。

C：仅隔离修复候选。T：仅本表专项、lint、解析；保留环境错误。U：未验。生产代码未应用，未 commit/push，未关闭 P0-2 资产/源码发布绑定、历史 phys、访问冲突、冻结带发布等问题。

未实测：帮助 GUI、五关驾驶、真人窗口切换、近竖直备用 UP 切换边界的连续画面和滚转观感、全量 suite、AC-13、音频、冻结带回放、新导出包。人工验收仍需三视角后视、暂停/退出确认/失焦恢复和倒计时操作录像；截图或本专项不能替代 U。

回退仅放弃隔离绿色候选及其独立增量；原工作区无需回退，不使用 reset/clean/stash。

本地证据 ZIP 只打包报告、补丁、测试版本、指定源码、原始日志及收据，逐文件哈希核验；没有完整资产与导入缓存，不能独立运行游戏，也未发布。
