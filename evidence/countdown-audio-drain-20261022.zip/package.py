"""Archive immutable test evidence and independently verify every payload hash."""
from pathlib import Path
import hashlib
import json
import re
import shutil
import subprocess
from zipfile import ZipFile, ZIP_DEFLATED

out = Path(__file__).resolve().parent
repo = out.parent.parent
snapshot = out / 'source-snapshot'
changed = []
with ZipFile(out / 'baseline-source.zip') as z:
    for name in z.namelist():
        if not name.endswith('/') and (snapshot / name).read_bytes() != z.read(name):
            changed.append(name)
assert sorted(changed) == ['godot-racer/tests/countdown_scene_test.gd', 'godot-racer/tests/race_clock_scene_test.gd'], changed
positive = ['countdown-60', 'countdown-120', 'clock-60', 'clock-120', 'contract', 'mixed-audio', 'lifecycle', 'owner']
for case in positive:
    r = json.loads((out / f'{case}.result.json').read_text(encoding='utf-8'))
    assert r['passed'] and r['exit'] == 0 and not (r['timeout'] or r['leak'] or r['script_error']), case
    for name, digest in r['source_hashes'].items():
        assert hashlib.sha256((snapshot / 'godot-racer' / name).read_bytes()).hexdigest() == digest, (case, name)
for case in ['red-countdown-60', 'delay-control-120']:
    r = json.loads((out / f'{case}.result.json').read_text(encoding='utf-8'))
    assert r['exit'] == 1 and not r['script_error'] and not r['timeout'] and r['summaries'] == [['31', '30', '1']], case
raw = (out / 'delay-control-120.console.log').read_text(encoding='utf-8')
assert '"budget_ok":false' in raw and '"continuity_ok":true' in raw
assert '✔ all scene audio playbacks reclaimed before process quit' in raw
static = json.loads((out / 'static-results.json').read_text(encoding='utf-8'))
assert all(r['exit'] == 0 for n, r in static.items() if n != 'lines')
sources = ['godot-racer/tests/countdown_scene_test.gd', 'godot-racer/tests/race_clock_scene_test.gd',
           'godot-racer/tests/audio_exit_probe.gd', 'godot-racer/docs/testing.md',
           'plan/countdown-audio-drain-20261022.md', 'HANDOVER-2026-10-22-AUDIO-DRAIN-PAUSE.md']
for name in sources:
    target = out / 'delivery-source' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(repo / name, target)
before = set((out / 'status-before.txt').read_text(encoding='utf-8').splitlines())
after_raw = subprocess.check_output(['git', 'status', '--short']).decode('utf-8')
after = set(after_raw.splitlines())
own = set(sources) | {'evidence/countdown-audio-drain-20261022.zip', 'evidence/countdown-audio-drain-20261022.zip.sha256'}
unrelated = lambda lines: {s for s in lines if s[3:] not in own}
assert unrelated(before) == unrelated(after), (unrelated(before) ^ unrelated(after))
(out / 'status-after.txt').write_text(after_raw, encoding='utf-8')
audit = dict(source_base='ab30904645e27ec372ef01a0d300be99ff75eae6', changed_source=changed,
             natural_cases=positive, expected_negative='delay-control-120', unrelated_status_unchanged=True,
             baseline_zip_sha256=hashlib.sha256((out / 'baseline-source.zip').read_bytes()).hexdigest())
(out / 'final-audit.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding='utf-8')
files = [p for p in out.iterdir() if p.is_file() and p.suffix != '.zip' and not p.name.endswith('.zip.sha256') and p.name != 'package-verification.json']
files += [p for p in (out / 'delivery-source').rglob('*') if p.is_file()]
payload = {str(p.relative_to(out)).replace('\\', '/'): p.read_bytes() for p in sorted(files)}
manifest = ''.join(hashlib.sha256(raw).hexdigest() + '  ' + name + '\n' for name, raw in payload.items())
target = repo / 'evidence/countdown-audio-drain-20261022.zip'
assert not target.exists(), target
with ZipFile(target, 'w', ZIP_DEFLATED) as z:
    for name, raw in payload.items():
        z.writestr(name, raw)
    z.writestr('MANIFEST.sha256', manifest)
with ZipFile(target) as z:
    for line in z.read('MANIFEST.sha256').decode('utf-8').splitlines():
        digest, name = line.split('  ', 1)
        assert hashlib.sha256(z.read(name)).hexdigest() == digest, name
digest = hashlib.sha256(target.read_bytes()).hexdigest()
target.with_suffix('.zip.sha256').write_text(digest + '  ' + target.name + '\n', encoding='utf-8')
receipt = dict(files=len(payload), manifest_verified=True, zip_sha256=digest, bytes=target.stat().st_size)
(out / 'package-verification.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
print(json.dumps(receipt))
