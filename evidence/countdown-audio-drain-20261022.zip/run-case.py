"""One serial real-exe case, immutable receipts, strict final evidence."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
PROJECT = OUT / 'source-snapshot/godot-racer'
name, script, fps, *extra = sys.argv[1:]
if (OUT / f'{name}.process.json').exists():
    raise SystemExit('Refusing to overwrite evidence: ' + name)
engine_extra = []
for arg in extra[:]:
    if arg.startswith('--engine-frame-delay='):
        engine_extra += ['--frame-delay', str(int(arg.split('=', 1)[1]))]
        extra.remove(arg)
command = [r'E:\godot\Godot_v4.4.1-stable_win64.exe', '--path', str(PROJECT),
           '--verbose', '--log-file', str(OUT / f'{name}.log'), '--headless',
           '--audio-driver', 'Dummy', '--script', script, *engine_extra,
           '--', f'--render-fps={fps}', *extra]
hashes = {p: hashlib.sha256((PROJECT / p).read_bytes()).hexdigest() for p in [
    script.removeprefix('res://'), 'tests/countdown_scene_test.gd',
    'tests/race_clock_scene_test.gd', 'tests/audio_exit_probe.gd']}
started = time.monotonic()
process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                           creationflags=subprocess.CREATE_NO_WINDOW)
receipt = dict(case=name, pid=process.pid, command=command, source_hashes=hashes)
(OUT / f'{name}.process.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding='utf-8')
timeout = False
try:
    stdout, stderr = process.communicate(timeout=60)
except subprocess.TimeoutExpired:
    timeout = True
    process.kill()
    stdout, stderr = process.communicate()
(OUT / f'{name}.console.log').write_bytes(stdout)
(OUT / f'{name}.stderr.log').write_bytes(stderr)
(OUT / f'{name}.exit.txt').write_text(str(process.returncode), encoding='utf-8')
raw = stdout.decode('utf-8', errors='replace') + stderr.decode('utf-8', errors='replace')
patterns = {
    'countdown_scene_test.gd': (r'^CASES: (\d+) PASS: (\d+) FAIL: (\d+)\r?$', [('31', '31', '0')], 'COUNTDOWN_SCENE_PASS', r'^  ✔ ', 31),
    'race_clock_scene_test.gd': (r'^RACE_CLOCK_SCENE_SUMMARY pass=(\d+) fail=(\d+) fps=(\d+)\r?$', [('42', '0', fps)], 'RACE_CLOCK_SCENE_PASS', r'^PASS ', 42),
    'countdown_clock_contract_test.gd': (r'^CLOCK_CONTRACT_SUMMARY pass=(\d+) fail=(\d+)\r?$', [('21', '0')], 'CLOCK_CONTRACT_PASS', r'^PASS ', 21),
    'audio_exit_probe_test.gd': (r'^AUDIO_EXIT_SUMMARY PASS=(\d+) FAIL=(\d+)\r?$', [('14', '0')], None, r'^AUDIO_EXIT PASS ', 14),
    'engine_audio_owner_test.gd': (r'^AUDIO_OWNER_SUMMARY PASS=(\d+) FAIL=(\d+)\r?$', [('12', '0')], None, r'^AUDIO_OWNER PASS ', 12),
    'engine_audio_lifecycle_test.gd': (r'^CASES: (\d+) PASS: (\d+) FAIL: (\d+)\r?$', [('19', '19', '0')], 'ENGINE_AUDIO_LIFECYCLE_PASS', r'^PASS ', 19),
}
pattern, want, marker, pass_pattern, count = patterns[Path(script).name]
summaries = re.findall(pattern, raw, re.M)
complete = (summaries == want and len(re.findall(pass_pattern, raw, re.M)) == count
            and (marker is None or raw.count(marker) == 1))
leak = bool(re.search(r'ObjectDB instances leaked|Leaked instance:|resources still in use', raw))
script_error = bool(re.search(r'SCRIPT ERROR|Parse Error', raw))
receipt.update(exit=process.returncode, elapsed_s=round(time.monotonic()-started, 3),
               timeout=timeout, leak=leak, script_error=script_error,
               summaries=summaries, complete=complete,
               errors=re.findall(r'^.*ERROR:.*$', raw, re.M),
               passed=process.returncode == 0 and complete and not (timeout or leak or script_error))
(OUT / f'{name}.result.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({k: v for k, v in receipt.items() if k not in ('command', 'source_hashes')}, ensure_ascii=False), flush=True)
raise SystemExit(0 if receipt['passed'] else 1)
