Sources: baseline 7e255c8 plus documented worktree; final source snapshot 8e2de4d.
Old matrix: 19 process successes / 1 access violation; preserve failure.
Engine-only drain matrix: 20 process exits 0, 19 runner passes / 1 rain leak.
Rain follow-ups are separate runs, never a merged 20/20 result.
Full 80-image sets and the 53MB source archive remain local; selected images included.
snapshot-import first attempt timed out; retry exit 0 still has editor environment errors.
Native crash PID 20064 has no captured stack or verified command line.
