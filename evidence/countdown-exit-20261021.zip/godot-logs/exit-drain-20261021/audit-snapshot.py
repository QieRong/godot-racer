from pathlib import Path
from zipfile import ZipFile
import hashlib, json
out=Path('godot-logs/exit-drain-20261021')
results=[]
with ZipFile(out/'source-snapshot.zip') as z:
    for name in z.namelist():
        if name.startswith('godot-racer/') and (name.endswith(('.gd','.tscn','.tres','.gd.uid')) or name=='godot-racer/project.godot'):
            path=out/'source-snapshot'/name
            expected=z.read(name)
            results.append({'path':name,'same':path.exists() and path.read_bytes()==expected,'sha256':hashlib.sha256(expected).hexdigest()})
(out/'snapshot-source-audit.json').write_text(json.dumps({'source_commit':'8e2de4d821b7bbbae6dbde2f049143cbc449a352','files':results},ensure_ascii=False,indent=2),encoding='utf-8')
print('SOURCE_AUDIT',len(results),'mismatches:',sum(not r['same'] for r in results))
for r in results:
    if not r['same']:print(r['path'])
