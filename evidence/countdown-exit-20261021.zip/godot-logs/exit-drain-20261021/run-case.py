import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

out = Path(__file__).resolve().parent
repo = out.parent.parent
name, script, *extra = sys.argv[1:]
command = [r'E:\godot\Godot_v4.4.1-stable_win64.exe', '--path',
           os.environ.get('RACER_TEST_PROJECT', str(repo / 'godot-racer')), '--verbose', '--log-file',
           str(out / f'{name}.log'), '--script', script, *extra]
started = time.monotonic()
process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                           creationflags=subprocess.CREATE_NO_WINDOW)
metadata = {'case': name, 'pid': process.pid, 'command': command}
(out / f'{name}.process.json').write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding='utf-8')
timed_out = False
try:
    stdout, stderr = process.communicate(timeout=60)
except subprocess.TimeoutExpired:
    timed_out = True
    process.kill()
    stdout, stderr = process.communicate()
(out / f'{name}.console.log').write_bytes(stdout)
(out / f'{name}.stderr.log').write_bytes(stderr)
(out / f'{name}.exit.txt').write_text(str(process.returncode), encoding='utf-8')
raw = stdout.decode('utf-8', errors='replace') + stderr.decode('utf-8', errors='replace')
markers = re.findall(r'^.*(?:SUMMARY|CASES:|_PASS$|_FAIL$|AUDIO_DRAIN_|UI_RUNTIME_DONE).*$', raw, re.M)
leak = bool(re.search(r'ObjectDB instances leaked|Leaked instance:|resources still in use', raw))
failed = bool(re.search(r'SCRIPT ERROR|Parse Error|READABILITY FAIL|AUDIO_OWNER FAIL|^FAIL |AUDIO_DRAIN_TIMEOUT|FAIL=[1-9]|FAIL: [1-9]', raw, re.M))
expected = bool(re.search(r'READABILITY_SUMMARY|AUDIO_OWNER_SUMMARY|AUDIO_EXIT_SUMMARY|ENGINE_AUDIO_LIFECYCLE_PASS|COUNTDOWN_SCENE_PASS|FINISH_RESULTS_PASS|REL_FINAL_FINISHFLOW_PASS|UI_RUNTIME_DONE', raw))
metadata.update(exit=process.returncode, elapsed_s=round(time.monotonic()-started, 2),
                timeout=timed_out, leak=leak, failed=failed, markers=markers,
                errors=re.findall(r'^.*ERROR:.*$', raw, re.M),
                passed=process.returncode == 0 and expected and not (timed_out or leak or failed))
(out / f'{name}.result.json').write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({k:v for k,v in metadata.items() if k != 'command'}, ensure_ascii=False), flush=True)
sys.exit(0 if metadata['passed'] else 1)


