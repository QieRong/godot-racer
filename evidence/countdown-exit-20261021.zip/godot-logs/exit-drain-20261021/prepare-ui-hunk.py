from pathlib import Path
import difflib
import subprocess
repo=Path.cwd()
name='godot-racer/tests/ui_pages_test.gd'
base=subprocess.check_output(['git','show','HEAD:'+name]).decode('utf-8')
old='\t_check("CD-05", _find(_cd, "CountdownTitle").get_theme_color("font_color").is_equal_approx(Color("a8c4dc")), "L5当前关卡强调色")'
new='\t_check("CD-05", _find(_cd, "CountdownTitle").get_theme_color("font_color").is_equal_approx(Color("f3f6fa"))\n\t\tand _find(_cd, "CountdownTitle").get_theme_constant("outline_size") >= 4,\n\t\t"五关统一亮字黑描边；主题色保留信号灯")'
assert base.count(old)==1
patch=''.join(difflib.unified_diff(base.splitlines(keepends=True),base.replace(old,new).splitlines(keepends=True),fromfile='a/'+name,tofile='b/'+name))
Path('godot-logs/exit-drain-20261021/ui-pages-stage.patch').write_bytes(patch.encode('utf-8'))
print(patch)
