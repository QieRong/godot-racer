from pathlib import Path
import hashlib
import zipfile

repo = Path(__file__).resolve().parents[2]
dest = repo / 'evidence'
dest.mkdir(exist_ok=True)
paths = []
old = repo / 'godot-logs/countdown-readability-20261021'
for pattern in ['audio-owner-*', 'audio-lifecycle-after-owner.*', 'exit-owner-regression-audit.csv', 'owner-final-results.csv']:
    paths.extend(old.glob(pattern))
new = Path(__file__).resolve().parent
for pattern in ['owner.*', 'engine_audio.before.gd']:
    paths.extend(new.glob(pattern))
paths.extend([repo / 'godot-racer/scripts/engine_audio.gd', repo / 'godot-racer/tests/engine_audio_owner_test.gd'])
target = dest / 'audio-owner-20261021.zip'
with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED) as z:
    manifest = []
    for path in sorted(set(paths)):
        data = path.read_bytes()
        name = path.relative_to(repo).as_posix()
        z.writestr(name, data)
        manifest.append(f'{hashlib.sha256(data).hexdigest()}  {name}')
    z.writestr('MANIFEST.sha256', '\n'.join(manifest)+'\n')
digest = hashlib.sha256(target.read_bytes()).hexdigest()
target.with_suffix('.zip.sha256').write_text(f'{digest}  {target.name}\n', encoding='ascii')
print(target, target.stat().st_size, digest)
