extends SceneTree
func _initialize() -> void:
	print("PROBE_UID=", ResourceUID.id_to_text(ResourceUID.create_id()))
	print("MIXED_TEST_UID=", ResourceUID.id_to_text(ResourceUID.create_id()))
	quit()
