from pathlib import Path
import json, subprocess
out=Path(__file__).resolve().parent
project=out/'source-snapshot/godot-racer'
command=[r'E:\godot\Godot_v4.4.1-stable_win64.exe','--headless','--path',str(project),'--import','--verbose','--log-file',str(out/'snapshot-import-02.log')]
p=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,creationflags=subprocess.CREATE_NO_WINDOW)
(out/'snapshot-import-02.process.json').write_text(json.dumps({'pid':p.pid,'command':command},ensure_ascii=False,indent=2),encoding='utf-8')
try:
    stdout,stderr=p.communicate(timeout=60)
except subprocess.TimeoutExpired:
    p.kill(); stdout,stderr=p.communicate(); print('SNAPSHOT_IMPORT_TIMEOUT')
(out/'snapshot-import-02.console.log').write_bytes(stdout)
(out/'snapshot-import-02.stderr.log').write_bytes(stderr)
(out/'snapshot-import-02.exit.txt').write_text(str(p.returncode))
print('SNAPSHOT_IMPORT_EXIT',p.returncode)
print(stderr.decode('utf-8',errors='replace')[-2200:])
raise SystemExit(p.returncode)

