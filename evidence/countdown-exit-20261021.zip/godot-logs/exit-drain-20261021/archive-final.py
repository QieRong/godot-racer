from pathlib import Path
import hashlib
import json
import zipfile

here = Path(__file__).resolve().parent
repo = here.parents[1]
paths = []
for folder in [here, repo/'godot-logs/countdown-readability-20261021-matrix',
               repo/'godot-logs/countdown-exit-drain-20261021-matrix']:
    paths.extend(p for p in folder.iterdir() if p.is_file() and p.suffix in {'.log','.txt','.json','.csv','.gd','.py','.patch'})
old = repo/'godot-logs/countdown-readability-20261021'
for pattern in ['red-l4*', 'green-l4-720.*', 'owner-final-*.log', 'owner-final-*.txt',
                'owner-final-l4-forward-wasapi-*.png', 'owner-final-l5-forward-*.png',
                'qa-*.jpg', 'owner-final-results.csv', 'exit-owner-regression-audit.csv']:
    paths.extend(p for p in old.glob(pattern) if p.is_file())
paths.extend(here.glob('user-*.png'))
for name in ['start_countdown.gd','engine_audio.gd']:
    paths.append(repo/'godot-racer/scripts'/name)
for name in ['countdown_readability_test.gd','audio_exit_probe.gd','audio_exit_probe_test.gd',
             'engine_audio_lifecycle_test.gd','run-countdown-readability.ps1']:
    paths.append(repo/'godot-racer/tests'/name)
results = [json.loads(p.read_text(encoding='utf-8')) for p in here.glob('*.result.json')]
summary = [{'case':r['case'],'passed':r['passed'],'exit':r['exit'],'leak':r['leak'],
            'pid':r['pid'],'markers':r['markers']} for r in results]
(here/'final-audit.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
paths.append(here/'final-audit.json')
target=repo/'evidence/countdown-exit-20261021.zip'
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
    manifest=[]
    for path in sorted(set(paths)):
        name=path.relative_to(repo).as_posix()
        data=path.read_bytes()
        z.writestr(name,data)
        manifest.append(f'{hashlib.sha256(data).hexdigest()}  {name}')
    z.writestr('MANIFEST.sha256','\n'.join(manifest)+'\n')
    z.writestr('README.txt',
        'Sources: baseline 7e255c8 plus documented worktree; final source snapshot 8e2de4d.\n'
        'Old matrix: 19 process successes / 1 access violation; preserve failure.\n'
        'Engine-only drain matrix: 20 process exits 0, 19 runner passes / 1 rain leak.\n'
        'Rain follow-ups are separate runs, never a merged 20/20 result.\n'
        'Full 80-image sets and the 53MB source archive remain local; selected images included.\n'
        'snapshot-import first attempt timed out; retry exit 0 still has editor environment errors.\n'
        'Native crash PID 20064 has no captured stack or verified command line.\n')
digest=hashlib.sha256(target.read_bytes()).hexdigest()
target.with_suffix('.zip.sha256').write_text(f'{digest}  {target.name}\n',encoding='ascii')
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None
    for line in z.read('MANIFEST.sha256').decode().splitlines():
        expected,name=line.split('  ',1)
        assert hashlib.sha256(z.read(name)).hexdigest()==expected,name
print('ARCHIVE_VERIFIED',target.stat().st_size,digest)
