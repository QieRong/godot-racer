"""Read archived full-suite evidence; never start or alter a game run."""
import hashlib
import json
import sys
import zipfile
from pathlib import Path

fps = int(sys.argv[1])
root = Path(__file__).resolve().parent
prefix = root / f"review-p0c-20261021-normal-full{fps}"
runner = Path(str(prefix) + ".runner.log").read_text(encoding="utf-8-sig")
exit_code = int(Path(str(prefix) + ".runner-exit.txt").read_text(encoding="utf-8-sig").strip())
archive = Path(str(prefix) + "-checklogs.zip")
rows = []
with zipfile.ZipFile(archive) as z:
    for name in sorted(z.namelist()):
        raw = z.read(name)
        text = raw.decode("utf-8-sig")
        assertions, outcomes, identity = [], [], {}
        for line in text.splitlines():
            if line.startswith("RUNID|"):
                assertions, outcomes = [], []
                identity = json.loads(line.split("|", 1)[1])
            elif line.startswith("ASSERT|"):
                assertions.append(json.loads(line.split("|", 1)[1]))
            elif line.startswith("OUTCOME|"):
                outcomes.append(json.loads(line.split("|", 1)[1]))
        outcome = outcomes[-1] if outcomes else {}
        errors = [line for line in text.splitlines() if line.startswith(("ERROR:", "SCRIPT ERROR:"))]
        valid = (len(outcomes) == 1 and outcome.get("finished") is True
                 and outcome.get("measurement_status") == "COMPLETE"
                 and outcome.get("failed_assertions") == 0
                 and outcome.get("exit_code_requested") == 0
                 and outcome.get("assertion_records") == len(assertions) > 0
                 and any(a.get("result") == "PASS" for a in assertions)
                 and not any(a.get("result") == "FAIL" for a in assertions)
                 and identity.get("render_fps") == fps
                 and identity.get("physics_hz") == 120
                 and "[CHECK] 完成" in text)
        if "tape_summary" in outcome:
            outcome["tape_summary"] = {k: v for k, v in outcome["tape_summary"].items()
                                       if k != "gap_series"}
        rows.append({"log": name, "sha256": hashlib.sha256(raw).hexdigest(),
                     "identity": identity,
                     "outcome": outcome, "check_passed": valid,
                     "error_lines": errors})
valid = exit_code == 0 and "全部 20 项通过" in runner and len(rows) == 18 and all(r["check_passed"] for r in rows)
result = {"render_fps": fps, "suite_exit": exit_code, "suite_all_20_pass": valid,
          "engine_log_count": len(rows), "docs_readme_count": 2,
          "failed_engine_checks": [r["log"] for r in rows if not r["check_passed"]],
          "process_exit_evidence": "run-all requires each child exit 0; run-check checks real process exit; per-child stdout not retained by existing run-all",
          "source_binding": "01122df plus existing dirty worktree; not clean-commit or export acceptance",
          "archive_sha256": hashlib.sha256(archive.read_bytes()).hexdigest(), "runs": rows}
Path(str(prefix) + "-audit.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({k: result[k] for k in ("render_fps", "suite_exit", "suite_all_20_pass", "engine_log_count")}))
print("ERROR_LINES=" + str(sum(len(r["error_lines"]) for r in rows)))
raise SystemExit(0 if valid else 1)
