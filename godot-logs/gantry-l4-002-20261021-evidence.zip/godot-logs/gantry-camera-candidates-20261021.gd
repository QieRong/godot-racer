extends SceneTree
## Temporary review only: real main scene/camera; no production source edits.

var game: Node
var rows: Array = []
var out := "D:/桌面/DSH-Work/data-analysis/godot-logs/gantry-camera-20261021b"

func _initialize() -> void:
	create_timer(90.0, true).timeout.connect(func(): quit(3))
	call_deferred("_run")

func _run() -> void:
	var state := root.get_node("GameState")
	state.set("settings_path", out + "-settings.cfg")
	state.set("chosen_level", 3)
	root.size = Vector2i(1366, 705)
	game = load("res://scenes/main.tscn").instantiate()
	root.add_child(game)
	current_scene = game
	for i in range(1500):
		await process_frame
		if bool(game.get("_setup_done")):
			break
	assert(bool(game.get("_setup_done")), "Main setup timeout")
	paused = true
	var camera := game.get_node("ChaseCamera") as Camera3D
	camera.call("set_view_mode", 2)
	camera.call("_update_camera", 0.0, true)
	var track := game.get_node("Track") as Node3D
	var old := game.get("_start_gantry") as Node3D
	game.remove_child(old)
	var source := FileAccess.get_file_as_string("res://scripts/start_gantry.gd")
	for candidate in [[4.4, 0.0], [4.2, 0.0], [5.5, 6.0]]:
		var h: float = candidate[0]
		var forward_m: float = candidate[1]
		var script := GDScript.new()
		script.source_code = source.replace("const GATE_TARGET_HEIGHT_M := 8.5", "const GATE_TARGET_HEIGHT_M := %.1f" % h)
		assert(script.reload() == OK)
		var module := script.new() as Node3D
		module.call("setup", track, 3)
		game.add_child(module)
		var gate := module.get_node("StartGantry") as Node3D
		var forward: Vector3 = track.get("start_line_forward")
		forward.y = 0.0
		gate.position += forward.normalized() * forward_m
		await process_frame
		camera.call("_update_camera", 0.0, true)
		await RenderingServer.frame_post_draw
		var rect := Rect2()
		var first := true
		var local_min := Vector3(INF, INF, INF)
		var local_max := Vector3(-INF, -INF, -INF)
		for mesh in gate.find_children("*", "MeshInstance3D", true, false):
			var m := mesh as MeshInstance3D
			if not m.is_visible_in_tree():
				continue
			var box := m.mesh.get_aabb()
			for k in range(8):
				var p := m.global_transform * box.get_endpoint(k)
				var lp := gate.to_local(p)
				local_min = local_min.min(lp)
				local_max = local_max.max(lp)
				var uv := camera.unproject_position(p)
				if first:
					rect = Rect2(uv, Vector2.ZERO)
					first = false
				else:
					rect = rect.expand(uv)
		var viewport_rect := root.get_visible_rect()
		var path := out + "-height-%.1f.png" % h
		var save_error := root.get_texture().get_image().save_png(path)
		var row := {"height_m": h, "forward_offset_m": forward_m, "dimensions_m": [local_max.x-local_min.x, local_max.y-local_min.y, local_max.z-local_min.z],
			"projected_min": [rect.position.x, rect.position.y], "projected_max": [rect.end.x, rect.end.y],
			"viewport": [viewport_rect.size.x, viewport_rect.size.y], "fully_inside_frame": viewport_rect.encloses(rect),
			"camera_position": str(camera.global_position), "car_position": str(camera.target.global_position),
			"screenshot": path, "save_error": save_error}
		rows.append(row)
		print("GANTRY_CANDIDATE " + JSON.stringify(row))
		game.remove_child(module)
		module.free()
	game.add_child(old)
	var file := FileAccess.open(out + "-metrics.json", FileAccess.WRITE)
	file.store_string(JSON.stringify(rows, "  "))
	file.close()
	game.queue_free()
	paused = false
	await process_frame
	print("GANTRY_REVIEW_DONE candidates=3 production_source_unchanged=true")
	quit(0)
