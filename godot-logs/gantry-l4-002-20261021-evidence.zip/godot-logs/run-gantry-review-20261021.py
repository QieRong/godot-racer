import json
from pathlib import Path
import subprocess
import sys

base = Path(__file__).resolve().parent
project = base.parent / 'godot-racer'
stage = sys.argv[1]
cases = [
    ('geo', ['--headless', '--script', 'res://tools/gantry-l4b-geocheck.gd']),
    ('camera', ['--script', 'res://tests/gantry_camera_test.gd', '--resolution', '1366x705']),
]
results = []
for name, args in cases:
    prefix = base / f'gantry-l4-002-{stage}-{name}'
    cmd = [r'E:\godot\Godot_v4.4.1-stable_win64.exe', '--path', str(project),
           '--audio-driver', 'Dummy', '--log-file', str(prefix) + '-engine.log', *args,
           '--', '--gantry-out=' + str(prefix)]
    if stage == 'green' and name == 'camera':
        cmd.append('--gantry-export-model')
    with Path(str(prefix) + '-console.log').open('wb') as log:
        result = subprocess.run(cmd, stdout=log, stderr=subprocess.STDOUT,
                                timeout=110, creationflags=subprocess.CREATE_NO_WINDOW)
    Path(str(prefix) + '-exit.txt').write_text(str(result.returncode), encoding='utf-8')
    text = Path(str(prefix) + '-engine.log').read_text(encoding='utf-8')
    markers = [line for line in text.splitlines() if '汇总' in line or
               'SUMMARY' in line or 'FAIL' in line or 'SCRIPT ERROR' in line or 'ERROR:' in line]
    row = {'stage': stage, 'case': name, 'exit': result.returncode, 'markers': markers}
    results.append(row)
    print(json.dumps(row, ensure_ascii=False), flush=True)
(base / f'gantry-l4-002-{stage}-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding='utf-8')
