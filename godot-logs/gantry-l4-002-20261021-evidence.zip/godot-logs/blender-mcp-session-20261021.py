import argparse
import asyncio
import base64
import json
import os
from pathlib import Path
import shutil
import tomllib

BASE = Path(__file__).resolve().parent
UVX = r'C:\Users\Administrator\.local\bin\uvx.exe'
ARGS = ['--offline', 'blender-mcp==2.0.0']
ENV = {'BLENDER_HOST': '127.0.0.1', 'BLENDER_PORT': '9876',
       'BLENDER_MCP_DISABLE_TELEMETRY': '1'}


def configure():
    config = Path(r'C:\Users\Administrator\.codex\config.toml')
    raw = config.read_bytes()
    before = tomllib.loads(raw.decode('utf-8-sig'))
    servers = before.get('mcp_servers', {})
    if 'blender' in servers:
        raise RuntimeError('Existing blender entry: inspect before updating')
    backup = config.with_name('config.toml.before-blender-20261021.bak')
    if backup.exists():
        raise RuntimeError('Backup already exists; do not overwrite')
    shutil.copyfile(config, backup)
    addition = '''

[mcp_servers.blender]
command = 'C:\\Users\\Administrator\\.local\\bin\\uvx.exe'
args = ['--offline', 'blender-mcp==2.0.0']
enabled = true
startup_timeout_sec = 60
tool_timeout_sec = 120
env = { BLENDER_HOST = "127.0.0.1", BLENDER_PORT = "9876", BLENDER_MCP_DISABLE_TELEMETRY = "1" }
'''
    updated = raw + addition.encode('utf-8')
    after = tomllib.loads(updated.decode('utf-8-sig'))
    added = after['mcp_servers'].pop('blender')
    assert after == before, 'Unrelated configuration changed'
    config.write_bytes(updated)
    assert tomllib.loads(config.read_text(encoding='utf-8-sig'))['mcp_servers']['blender'] == added
    print(json.dumps({'configured': 'blender', 'server': added,
                      'other_settings_unchanged': True}, ensure_ascii=False))


IMPORT_CODE = r'''
import bpy, json
from mathutils import Vector, Quaternion
before = {s.name: sorted(o.name for o in s.objects) for s in bpy.data.scenes}
original_scene = bpy.context.scene.name
original_file = bpy.data.filepath
scene = bpy.data.scenes.new('Racer_Gantry_Review')
bpy.context.window.scene = scene
scene.unit_settings.system = 'METRIC'
bpy.ops.import_scene.gltf(filepath='D:/桌面/DSH-Work/data-analysis/godot-racer/models/environment/desert_ruin_gate.glb')
bpy.context.view_layer.update()
meshes = [o for o in scene.objects if o.type == 'MESH']
assert meshes, 'No imported meshes'
corners = [o.matrix_world @ Vector(c) for o in meshes for c in o.bound_box]
lo = Vector(tuple(min(c[i] for c in corners) for i in range(3)))
hi = Vector(tuple(max(c[i] for c in corners) for i in range(3)))
center = (lo + hi) * 0.5
for o in scene.objects:
    o.select_set(o.type == 'MESH')
bpy.context.view_layer.objects.active = meshes[0]
for screen in bpy.data.screens:
    for area in screen.areas:
        if area.type == 'VIEW_3D':
            space = area.spaces.active
            space.shading.type = 'SOLID'
            space.shading.color_type = 'MATERIAL'
            space.region_3d.view_location = center
            space.region_3d.view_distance = max(hi - lo) * 1.9
            space.region_3d.view_rotation = Vector((0.25, -1.0, 0.2)).to_track_quat('Z', 'Y')
            space.region_3d.view_perspective = 'PERSP'
            area.tag_redraw()
preserved = all(sorted(o.name for o in bpy.data.scenes[n].objects) == objects for n, objects in before.items())
assert preserved, 'Original scene objects changed'
print(json.dumps({'scene': scene.name, 'original_scene': original_scene,
 'original_file': original_file, 'original_scenes_preserved': preserved,
 'saved_over_original': False, 'mesh_count': len(meshes),
 'objects': [o.name for o in scene.objects], 'bounds_min': list(lo),
 'bounds_max': list(hi), 'dimensions_m': list(hi-lo)}, ensure_ascii=False))
'''


async def run(action):
    from mcp import ClientSession, StdioServerParameters
    from mcp.client.stdio import stdio_client
    params = StdioServerParameters(command=UVX, args=ARGS, env={**os.environ, **ENV})
    with (BASE / f'blender-mcp-{action}-20261021.stderr.log').open('w', encoding='utf-8') as err:
        async with stdio_client(params, errlog=err) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                listing = await session.list_tools()
                names = [t.name for t in listing.tools]
                print(json.dumps({'mcp_initialized': True, 'tools': names}))
                if action == 'probe':
                    result = await session.call_tool('get_scene_info', {'user_prompt': 'blender我也打开了，你看看mcp能不能用'})
                elif action == 'import':
                    result = await session.call_tool('execute_blender_code', {'code': IMPORT_CODE, 'user_prompt': '然后用blender打开模型'})
                elif action == 'look':
                    result = await session.call_tool('look', {'mode': 'viewport', 'max_size': 1200, 'user_prompt': '然后用blender打开模型'})
                else:
                    raise ValueError(action)
                data = result.model_dump(mode='json')
                (BASE / f'blender-mcp-{action}-20261021.json').write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
                for item in result.content:
                    if item.type == 'text':
                        print(item.text)
                    elif item.type == 'image':
                        path = BASE / 'blender-gantry-open-20261021.png'
                        path.write_bytes(base64.b64decode(item.data))
                        print(str(path))
                if result.isError:
                    raise RuntimeError('MCP call returned error')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['configure', 'probe', 'import', 'look'])
    args = parser.parse_args()
    if args.action == 'configure':
        configure()
    else:
        asyncio.run(run(args.action))
