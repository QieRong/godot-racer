import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

logs = Path(__file__).resolve().parent
root = logs.parent
archive = logs / 'gantry-l4-002-20261021-evidence.zip'
assert not archive.exists(), 'Do not overwrite evidence archive'
paths = set()
for pattern in ['gantry-l4-002-*', 'gantry-camera-20261021*',
                'blender-mcp-*-20261021.*', 'blender-gantry-open-20261021.png']:
    paths.update(p for p in logs.glob(pattern) if p.is_file() and p != archive and p.suffix != '.zip')
for name in ['blender-mcp-session-20261021.py', 'run-gantry-review-20261021.py',
             'gantry-camera-candidates-20261021.gd', 'archive-gantry-20261021.py']:
    paths.add(logs / name)
for name in ['scripts/start_gantry.gd', 'tools/gantry-l4b-geocheck.gd',
             'tools/gantry-l4b-shots.gd', 'tests/gantry_camera_test.gd',
             'tests/gantry_camera_test.gd.uid']:
    paths.add(root / 'godot-racer' / name)
paths.add(root / 'plan/gantry-l4-002-20261021.md')
bindings = {}
for name in ['project.godot', 'scenes/main.gd', 'scripts/vehicle.gd',
             'scripts/track_generator.gd', 'scripts/chase_camera.gd',
             'scripts/start_gantry.gd', 'data/levels/level_4.tres']:
    p = root / 'godot-racer' / name
    bindings[name] = hashlib.sha256(p.read_bytes()).hexdigest()
entries = []
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
    for p in sorted(paths):
        data = p.read_bytes()
        rel = p.relative_to(root).as_posix()
        entries.append({'path': rel, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
        z.writestr(rel, data)
    manifest = {'head_before_gantry': subprocess.check_output(['git','rev-parse','HEAD'], cwd=root, text=True).strip(),
                'scope': 'dirty working tree; not clean checkout or user acceptance',
                'bindings_sha256': bindings, 'entries': entries}
    z.writestr('EVIDENCE-MANIFEST.json', json.dumps(manifest, ensure_ascii=False, indent=2))
with zipfile.ZipFile(archive) as z:
    saved = json.loads(z.read('EVIDENCE-MANIFEST.json'))
    for item in saved['entries']:
        assert hashlib.sha256(z.read(item['path'])).hexdigest() == item['sha256']
digest = hashlib.sha256(archive.read_bytes()).hexdigest()
archive.with_suffix('.zip.sha256').write_text(digest + '  ' + archive.name + '\n', encoding='utf-8')
print(json.dumps({'archive':archive.name,'files_verified':len(entries),'sha256':digest,'bytes':archive.stat().st_size}))
